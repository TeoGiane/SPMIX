function plotnpcpdf(fgnum, ygrid, xgrid, flagRecalc)


nClmns = 1;
lnWidth = 2;
xgridlen = length(xgrid(1,:));
ypdf = reshape(repmat(ygrid, length(xgrid(1,:)), 1),1, length(ygrid)*length(xgrid(1,:)));
xpdf = repmat(xgrid, 1, length(ygrid));

if flagRecalc
    dataforRpred=[xpdf' ypdf'];
    save 'PredDataForR.txt' dataforRpred -ascii;
%    path(path,'C:/Program Files/R/R-3.2.2/bin');
    
    system('R CMD BATCH npest.r'); 
end

npcpdfvals = importdata('cdensPredFromR.txt');


%condpdftrue = dgppdfeval(ypdf, xpdf);
figure(fgnum);

for xind = 1:xgridlen
    subplot(ceil(xgridlen/nClmns),nClmns,xind);
    plot(ygrid, npcpdfvals(xind+xgridlen*(0:length(ygrid)-1)), 'LineStyle', ':', 'LineWidth', lnWidth);
    hold on;
end
