
miny = min(y);
maxy = max(y);
ygridPlot = miny:(maxy-miny)/100:maxy;
xgrid1d = [0.25, 0.75];
xgridRMSE = GridNDLin(xgrid1d, dx);
xgridPlot = [xgrid1d; xgrid1d(ceil(length(xgrid1d)/2))*ones(dx-1,length(xgrid1d))];
q = 0.0001;
fig_start_n = 21;
[priorsim_b, priorsim_mu, priorsim_alphaunn, priorsim_hy, priorsim_hx, priorsim_nuy, priorsim_nux, priorsim_m] ...
         = prior_simulator(b_, Hb_, mu_, Hmu_, A_, Ahy_, Bhy_, Ahx_, Bhx_, Anuy_, Bnuy_, Anux_, Bnux_, Am_, Amlogp_, Nsim); 
plotpostpdfdraws(fig_start_n, ygridPlot, xgridPlot, priorsim_b, priorsim_mu, priorsim_alphaunn, priorsim_hy, priorsim_hx, priorsim_nuy, priorsim_nux, priorsim_m, Nsim, 1, q);

figure(fig_start_n)
hold on;
[f, z] = ksdensity(y);
plot(z,f); 

%%%%%%%%%%%%%%%%%%%%%%%%%%%

% script to be run after post_simulator, it plots post simultor output and
% performs mean equality tests for first and second moments of post

ts_filter=1:Nsim;
burnin_len = 1;
param_index = 1;
figure(fig_start_n+1)
for testd = 1:dx+1;
   [f, z] = ksdensity(squeeze(priorsim_b(testd,param_index,burnin_len:end)));
    plot(z,f); 
    hold on;
end
title('\beta_{kj}, j=1 and k=1,\ldots,d_x');

figure(fig_start_n+2)
[f, z] = ksdensity(squeeze(priorsim_hy(param_index,burnin_len:end)), 'support', 'positive');
plot(z,f); 
title('hy');

figure(fig_start_n+3)
[f, z] = ksdensity(squeeze(priorsim_nuy(param_index,burnin_len:end)), 'support', 'positive');
plot(z,f); 
title('\nu_{yj}, j=1');

figure(fig_start_n+4)
[f, z] = ksdensity(sum(priorsim_alphaunn(:,burnin_len:end)), 'support', 'positive');
plot(z,f); 
title('Sum of \alpha_j');

figure(fig_start_n+5)
for testd = 1:dx 
   [f, z] = ksdensity(squeeze(priorsim_mu(testd,param_index,burnin_len:end)));
   plot(z,f); 
   hold on;
end
title('\mu_{kj}, j=1, k=1,\ldots,d_x');

figure(fig_start_n+6)
for testd = 1:dx
   [f, z] = ksdensity(squeeze(priorsim_nux(testd,param_index,burnin_len:end)), 'support', 'positive');
   plot(z,f); 
   hold on;
end
title('\nu_{xkj}, j=1, k=1,\ldots,d_x');

figure(fig_start_n+7)
for testd = 1:dx
    [f, z] = ksdensity(squeeze(priorsim_hx(testd,burnin_len:end)), 'support', 'positive');
    plot(z,f); 
    hold on;
end
title('h_{xk}, k=1,\ldots,d_x');

if Amlogp_ == 0
    probm = exp(-Am_*(1:max(priorsim_m)))*(exp(Am_)-1);%knowm pmf constant
    m_prior_mean = 1./(1-exp(-Am_));
else
    mpriorPMF = exp(-Am_.*(1:50).*(log(1:50).^Amlogp_));
    mpriorPMF = mpriorPMF./sum(mpriorPMF);
    m_prior_mean = (1:50)*mpriorPMF';
    probm = mpriorPMF(1:max(priorsim_m));
end
for msupp = 1:max(priorsim_m)
   freqm(msupp) = sum(priorsim_m == msupp)./length(priorsim_m);
end
figure(fig_start_n+8)
plot(freqm)
hold on;
plot(probm,'LineStyle','--')
title('m');


