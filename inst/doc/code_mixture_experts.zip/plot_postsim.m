% plots post simultor output 
%tic
%close all;
ts_filter=1:Nsim;

Max_m = max(sim_m);

figure(1)
for testd = 1:dx+1;
    for param_index = 1:Max_m
        plseries = squeeze(sim_b(testd,param_index,ts_filter));
        scatter(ts_filter(plseries ~= 0), plseries(plseries ~= 0), '.');
        hold on;
     end
end
title('\beta_{jk}');
saveas(gcf,'beta.jpg');

figure(2)
for param_index = 1:1
    plseries = squeeze(sim_hy(param_index,ts_filter));
    scatter(ts_filter(plseries ~= 0), plseries(plseries ~= 0), '.');
    hold on;
end
title('h_y');
saveas(gcf,'h_y.jpg');

figure(3)
for param_index = 1:Max_m
    plseries = squeeze(sim_nuy(param_index,ts_filter));
    scatter(ts_filter(plseries ~= 0), plseries(plseries ~= 0), '.');
    hold on;
 end
title('\nu_{yj}');
saveas(gcf,'nuy.jpg');

figure(4)
for param_index = 1:Max_m
    plseries = squeeze(sim_alphaunn(param_index,ts_filter));
    scatter(ts_filter(plseries ~= 0), plseries(plseries ~= 0), '.');
    hold on;
end
title('\alpha_{j}');
saveas(gcf,'alpha.jpg');

figure(5)
for testd = 1:dx;
    for param_index = 1:Max_m
        plseries = squeeze(sim_mu(testd,param_index,ts_filter));
        scatter(ts_filter(plseries ~= 0), plseries(plseries ~= 0), '.');
        hold on;
     end
end
title('\mu_{jd}');
saveas(gcf,'mu.jpg');

figure(6)
for testd = 1:dx;
    for param_index = 1:Max_m
        plseries = squeeze(sim_nux(testd,param_index,ts_filter));
        scatter(ts_filter(plseries ~= 0), plseries(plseries ~= 0), '.');
        hold on;
     end
end
title('\nu^x_{jd}');
saveas(gcf,'nux.jpg');

figure(7)
for testd = 1:dx;
    plseries = squeeze(sim_hx(testd,ts_filter));
    scatter(ts_filter(plseries ~= 0), plseries(plseries ~= 0), '.');
    hold on;
end
title('h^x_{d}');
saveas(gcf,'hx.jpg');

figure(8)
scatter(ts_filter(sim_m ~= 0), sim_m(sim_m ~= 0), '.');
title('m');
saveas(gcf,'m.jpg');

figure(9)
scatter(ts_filter(currlogLikelihood ~= 0), currlogLikelihood(currlogLikelihood ~= 0), '.');
hold on;
title('Curr LogLikelihood');
saveas(gcf,'CurrLogLikelihood.jpg');

figure(10)
scatter(ts_filter(propPlogLikelihood ~= 0), propPlogLikelihood(propPlogLikelihood ~= 0), '.');
title('Prop m+1 LogLikelihood');
figure(11)
scatter(ts_filter(propMlogLikelihood ~= 0), propMlogLikelihood(propMlogLikelihood ~= 0), '.');
title('Prop m-1 LogLikelihood');
%toc
