%returns logarithm of the multivariate normal pdf parameterized with precision H (inverse of variance)
function res = lnnormpdf(x,mu,H)
res = -0.5*((x - mu)'*H*(x - mu)- logdet(H)+length(x)*log(2*pi));