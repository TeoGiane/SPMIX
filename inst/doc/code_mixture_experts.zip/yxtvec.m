% x=[x1; x2; ... xn], xi=[xi1,...,xim], y=[y1; y2; ... yn], yi=[yi1,...,yim], z(:,:,i) = yi' xi
function z = yxtvec(y,x)
[n m] = size(x);
z = reshape((repmat(y,1,m).* reshape(repmat(reshape(x',n*m,1), 1,m)',m^2,n)')', m,m,n);
