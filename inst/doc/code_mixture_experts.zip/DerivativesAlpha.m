% Hessian and Jacobian of the conditional posterior for alpha
function [J,H] = DerivativesAlpha(alpha, Np, Q, m, aexpQnorm)

if isempty(aexpQnorm)
    [aexpQnorm, ~] = Qnormsumlogsum(Q,alpha);
end
aexpQnormdiva = bsxfun(@rdivide, aexpQnorm,alpha);
diff_aexpQnormdiva = bsxfun(@minus, aexpQnormdiva(:,1:m-1),aexpQnormdiva(:,m));
J = (Np(1:m-1)'./alpha(1:m-1) - Np(m)'./alpha(m)  - sum(diff_aexpQnormdiva))';
H = -Np(m)./(alpha(m).^2) + sum( xxtvec(diff_aexpQnormdiva), 3);
H(1:m:(m-1)^2)=H(1:m:(m-1)^2) - Np(1:m-1)'./(alpha(1:m-1).^2);
