% Create d dimensional grid from 1d grid grid1d
function grid = GridNDLin(grid1d, d)
n = length(grid1d);
grid = zeros(d,n^d);
i = zeros(1,d);
for j = 1:n^d
    i(d) = mod(j,n);
    if i(d) == 0
        i(d) = n;
    end
    jsf = i(d);
    grid(d,j) = grid1d(i(d));
    for k = d-1:-1:1
       i(k) = mod(j - jsf, n^(d-k+1))./(n^(d-k)) + 1;
       jsf = jsf + (i(k)-1)* (n^(d-k));
       grid(k,j) = grid1d(i(k));
    end
end