library(np)
currPath = "C:/Users/anorets/Dropbox/work/projects/denregmcmc/engelcurve_estexper/mc_3_15_17/code_backup_3_15_17/"
estD<-read.table(paste(currPath,"EstDataForR.txt", sep = ""))
preD<-read.table(paste(currPath,"PredDataForR.txt", sep = ""))
ddim<-dim(estD)
dimx <- ddim[2]
Nobs <- ddim[1]
#V=data.frame(x=DP[1:ddim[1],1:ddim[2]-1],y=DP[1:ddim[1],ddim[2]])
xest=estD[1:Nobs,1:dimx-1]
yest=estD[1:Nobs,dimx]
xpre=preD[,1:dimx-1]
ypre=preD[,dimx]
bs <- npcdensbw(xest,yest)
P <- npcdens(bs,txdat=xest,tydat=yest,exdat=xpre,eydat=ypre)
AA<-P$condens
write.table(AA,file=paste(currPath,"cdensPredFromR.txt", sep = ""),row.names=FALSE,col.names=FALSE)
save(bs, P, file = paste(currPath,"bandwidthNP.RData", sep = ""))