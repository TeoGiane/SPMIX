This code produces estimation results in Section 7.5 of "Optimal auxiliary priors and reversible jump proposals
for a class of variable dimension models", by Andriy Norets

The main script is called realdata_estimation.m
This script contains some explanatory comments. 

The data for Engel curve estimation in file bn-data.csv
are obtained from the website of the Journal of Applied Econometrics and they were originally used in  
"Identification and Estimation of Engel Curves with Endogenous and Unobserved Expenditures", 
by Battistin and De Nadai, Journal of Applied Econometrics, Vol. 30, No. 3, 2015, pp. 487-508.

