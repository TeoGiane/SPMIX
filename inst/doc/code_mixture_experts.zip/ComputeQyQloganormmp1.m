function QyQloganormmp1 = ComputeQyQloganormmp1(Eps, nuymp1, hy, Q, alphamp1, Qy)

if nargin == 5
    Qy = -0.5*bsxfun(@minus, bsxfun(@times, Eps.^2, nuymp1.*hy), log(nuymp1.*hy));
end

QyQloga = Qy + bsxfun(@plus, Q, log(alphamp1));
QyQloga = bsxfun(@minus, QyQloga, max(QyQloga,[],2));
QyQloganormmp1 = exp(QyQloga(:,end))./sum(exp(QyQloga),2);

% Check if computes correctly      
% QyQloganormmp1prev = Qymp1DivLcomp.* aexpQnorm(:,m+1);
% sum(abs(QyQloganormmp1prev-QyQloganormmp1))
% zzzz = [QyQloganormmp1prev, QyQloganormmp1];
