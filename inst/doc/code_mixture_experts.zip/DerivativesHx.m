% Jacobian and Hessian of the conditional posterior for hx
function [J,H] = DerivativesHx(hx_pm, q, sumqisi, n, m, dx, x, mu, nux, alpha, Ahx_, Bhx_, aexpQnorm)
if isempty(aexpQnorm )
    Q = ComputeQ(n, m, dx, x, mu, nux, hx_pm);
    [aexpQnorm, ~] = Qnormsumlogsum(Q,alpha); 
end
cq = bsxfun(@times,q, reshape(aexpQnorm', 1, m*n));
%Scq = sum(reshape(cq,dx,m,n),2);
q_Scq = reshape(bsxfun(@minus, reshape(q,dx,m,n), sum(reshape(cq,dx,m,n),2)), dx, n*m);
J = sumqisi - sum(cq,2) + (Ahx_./2- 1)./hx_pm - 0.5*Bhx_.*hx_pm.^(-0.5);
H = -sum(yxtvec(cq',q_Scq'),3) - diag((Ahx_./2- 1)./hx_pm.^2 + 0.25*Bhx_.*hx_pm.^(-1.5));

