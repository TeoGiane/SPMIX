% Jacobian and Hessian of the conditional posterior for nuxj
function [J,H] = DerivativesNuxj(nuxj, x, hx, x_mj, Q, j, alpha, sum_rjsieqj05, r_j05, Anux_, Bnux_)
n = length(x(1,:));
Hjdiag = nuxj.*hx;
Hjx_mj = bsxfun(@times, x_mj, Hjdiag);
Q(:,j) = -0.5*sum(x_mj.*Hjx_mj,1)';
[aexpQnorm, ~] = Qnormsumlogsum(Q,alpha);
J =  -sum_rjsieqj05 + r_j05*aexpQnorm(:,j) + (Anux_- 1)./nuxj - Bnux_;
H = - sum(bsxfun(@times, xxtvec(r_j05'), reshape(aexpQnorm(:,j) - aexpQnorm(:,j).^2, 1,1,n)),3) ...
    - diag((Anux_- 1)./(nuxj.^2));
