% Jacobian and Hessian of the conditional posterior for muj
function [J,H] = DerivativesMuj(muj, x, Hjdiag, Hjsum_x, Q, j, alpha, N, mu_, Hmu_)
n = length(x(1,:));
x_mj = bsxfun(@minus, x, muj);
Hjx_mj = bsxfun(@times, x_mj, Hjdiag);
Q(:,j) = -0.5*sum(x_mj.*Hjx_mj,1)';
[aexpQnorm, ~] = Qnormsumlogsum(Q,alpha);
J =  Hjsum_x - N(j).*muj.*Hjdiag - Hjx_mj*aexpQnorm(:,j) - Hmu_ *(muj - mu_);
H = - sum(bsxfun(@times, xxtvec(Hjx_mj'), reshape(aexpQnorm(:,j) - aexpQnorm(:,j).^2, 1,1,n)),3) ...
              + diag( (sum(aexpQnorm(:,j))-N(j)) .*Hjdiag) - Hmu_;

