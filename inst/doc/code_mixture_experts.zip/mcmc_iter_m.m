% MCMC update of 
% (b, mu, alphaunn, hy, hx, nuy, nux) | m 


function [mdraw, b, mu, alphaunn, hy, hx, nuy, nux, m, currLogLklhd, propMlogLikelihood, propPlogLikelihood, mp1AccCount, mm1AccCount] ...
         = mcmc_iter_m(y, x, x1, xmean, xvar, olsb, olserrvar, dx, n,...
                        mp1AccCount, mm1AccCount, ...
                                b, mu, alphaunn, hy, hx, nuy, nux, m,...
                                b_, Hb_, mu_, Hmu_, A_, Ahy_, Bhy_, Ahx_, Bhx_, Anuy_, Bnuy_, Anux_, Bnux_, Am_, Amlogp_,Hb_b_)

    mdraw = 0;
%   Retrospective sampling for drawing  m      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   

    %GammaAFromMV = @(m,v) 0.5*(2+(m.^2)./v + sqrt((2+((m.^2)./v).^2).^2-4)); % matching gamma mode with m - worked worse than the following
    %GammaBFromMA = @(m,A) (A-(A>1))./m;
    GammaAFromMV = @(m,v) (m.^2)./v; % matching gamma mean works better
    GammaBFromMA = @(m,A) A./m;
    
    if rand < 0.5 
        %try to jump to m+1

        %Get initial values for theta^{m+1}
%         olsb=(x1*x1')\(x1*y');
%         olserrvar = mean((y - olsb'*x1).^2);
%         meanx=mean(x,2);
%         xvar = var(x,0,2);
%        z = mu(:,m);
        mump1_pm = xmean;
        bmp1_pm = olsb;   
        nuymp1_pm = 1./(olserrvar*hy);
        nuxmp1_pm = 1./(xvar.*hx);
        aunnmp1_pm =  0.1*A_./(m+1);%%initialize alphamp1(m+1) with a relatively small value
% tic
%         [mump1_pmsim, d2logPdmump12sim, bmp1_pmsim, d2logPdbmp12sim, nuxmp1_pmsim, d2logPdnuxmp12sim, nuymp1_pmsim, d2logPdnuymp12sim, aunnmp1_pmsim, d2logPdaunnmp12sim] ...
%                    = RetrPriorParams(n, m, dx, y, x, x1, hy, hx, b, mu, nux, nuy, alphaunn, bmp1_pm, mump1_pm, nuxmp1_pm, nuymp1_pm, aunnmp1_pm, b_, Hb_, mu_, Hmu_, A_, Anuy_, Bnuy_, Anux_, Bnux_);
% toc
% tic
        
        [mump1_pm, d2logPdmump12, bmp1_pm, d2logPdbmp12, nuxmp1_pm, d2logPdnuxmp12, nuymp1_pm, d2logPdnuymp12, aunnmp1_pm, d2logPdaunnmp12] ...
                  = RetrPriorParams(n, m, dx, y, x, x1, hy, hx, b, mu, nux, nuy, alphaunn, bmp1_pm, mump1_pm, nuxmp1_pm, nuymp1_pm, aunnmp1_pm, b_, Hb_, mu_, Hmu_, A_, Anuy_, Bnuy_, Anux_, Bnux_);
        %RetrPriorParamsMtlbOpt
 
%         toc
%  ComputeLogLklhd(n, m+1, dx, y, x, [b,bmp1_pm], [mu,mump1_pm], [nux,nuxmp1_pm], hx, x1, [nuy,nuymp1_pm], hy, [alphaunn,aunnmp1_pm])...
%   + lnnormpdf(mump1_pm, mu_, Hmu_) + lnnormpdf(bmp1_pm, b_, Hb_) + ...
%                                 sum(lngampdf(nuxmp1_pm,Anux_,Bnux_)) + lngampdf(nuymp1_pm,Anuy_,Bnuy_)  + lngampdf(aunnmp1_pm,A_./(m+1),1) ...              
%  -(ComputeLogLklhd(n, m+1, dx, y, x, [b,bmp1_pmsim], [mu,mump1_pmsim], [nux,nuxmp1_pmsim], hx, x1, [nuy,nuymp1_pmsim], hy, [alphaunn,aunnmp1_pmsim])...
%   + lnnormpdf(mump1_pmsim, mu_, Hmu_) + lnnormpdf(bmp1_pmsim, b_, Hb_) + ...
%                                 sum(lngampdf(nuxmp1_pmsim,Anux_,Bnux_)) + lngampdf(nuymp1_pmsim,Anuy_,Bnuy_)  + lngampdf(aunnmp1_pmsim,A_./(m+1),1))
%                 
              
        % draw retrospectively from prior
        d2logPdmump12inv = inv(d2logPdmump12);
        mump1_p = mvnrnd(mump1_pm,-d2logPdmump12inv)'; 
        d2logPdbmp12inv = inv(d2logPdbmp12);
        bmp1_p = mvnrnd(bmp1_pm,-d2logPdbmp12inv)'; 
        %nux
        d2logPdnuxmp12inv = inv(d2logPdnuxmp12);
        %nuxmp1_p = mvnrnd(nuxmp1_pm,-d2logPdnuxmp12inv)'; 
        %nuxmp1_p = norm_0_inf_rnd(nuxmp1_pm, sqrt(diag(-d2logPdnuxmp12inv)));
        nuxmp1A = GammaAFromMV(nuxmp1_pm, diag(-d2logPdnuxmp12inv)); nuxmp1B = GammaBFromMA(nuxmp1_pm, nuxmp1A); nuxmp1_p = gamrnd(nuxmp1A, 1./nuxmp1B);
        %nuy
        d2logPdnuymp12inv = inv(d2logPdnuymp12);
        %nuymp1_p = mvnrnd(nuymp1_pm,-d2logPdnuymp12inv)'; 
         %nuymp1_p = norm_0_inf_rnd(nuymp1_pm, sqrt(diag(-d2logPdnuymp12inv)));
        nuymp1A = GammaAFromMV(nuymp1_pm, diag(-d2logPdnuymp12inv)); nuymp1B = GammaBFromMA(nuymp1_pm, nuymp1A); nuymp1_p = gamrnd(nuymp1A, 1./nuymp1B);
        %aunn
        d2logPdaunnmp12inv = inv(d2logPdaunnmp12);
        %aunnmp1_p = mvnrnd(aunnmp1_pm,-d2logPdaunnmp12inv)';
        % aunnmp1_p = norm_0_inf_rnd(aunnmp1_pm, sqrt(diag(-d2logPdaunnmp12inv)));
        aunnmp1A = GammaAFromMV(aunnmp1_pm, diag(-d2logPdaunnmp12inv)); aunnmp1B = GammaBFromMA(aunnmp1_pm, aunnmp1A); aunnmp1_p = gamrnd(aunnmp1A, 1./aunnmp1B);

        %compute acceptance probability
        logRetrospPrior = lnnormpdf(mump1_p, mump1_pm, -d2logPdmump12) + lnnormpdf(bmp1_p, bmp1_pm, -d2logPdbmp12) +...
                                sum(lngampdf(nuxmp1_p,nuxmp1A,nuxmp1B)) + lngampdf(nuymp1_p,nuymp1A,nuymp1B)  + lngampdf(aunnmp1_p,aunnmp1A,aunnmp1B); 

       % alternative forms of prior, just normal is not really correct as negative values are not allowed, truncated univariate normals are similar to gamma
       % with matched modes, but gamma with matched mean is better.  In the future explore parameterization in logs and not disregarding correlatations 
       % truncated univ normals % lnnormpdftr0inf(nuxmp1_p,nuxmp1_pm,sqrt(diag(-d2logPdnuxmp12inv)))+lnnormpdftr0inf(nuymp1_p,nuymp1_pm,sqrt(diag(-d2logPdnuymp12inv)))+lnnormpdftr0inf(aunnmp1_p,aunnmp1_pm,sqrt(diag(-d2logPdaunnmp12inv)));
       % multivariate normal - incorrect due to possible negative values for positive parameters                     
        %                      0.5*((nuxmp1_p-nuxmp1_pm)'*d2logPdnuxmp12*(nuxmp1_p-nuxmp1_pm) + logdet(-d2logPdnuxmp12) -dx*log(2*pi)+...
        %                      (nuymp1_p-nuymp1_pm)'*d2logPdnuymp12*(nuymp1_p-nuymp1_pm) + logdet(-d2logPdnuymp12) -log(2*pi)+...
        %                      (aunnmp1_p-aunnmp1_pm)'*d2logPdaunnmp12*(aunnmp1_p-aunnmp1_pm) +logdet(-d2logPdaunnmp12)-log(2*pi)); % density constants are important here

        logPriorThetamp1 = lnnormpdf(mump1_p, mu_, Hmu_) + lnnormpdf(bmp1_p, b_, Hb_) + ...
                                sum(lngampdf(nuxmp1_p,Anux_,Bnux_)) + lngampdf(nuymp1_p,Anuy_,Bnuy_)  + lngampdf(aunnmp1_p,A_./(m+1),1);  

        currLogLklhd = ComputeLogLklhd(n, m, dx, y, x, b, mu, nux, hx, x1, nuy, hy, alphaunn);   
        propLogLklhd = ComputeLogLklhd(n, m+1, dx, y, x, [b,bmp1_p], [mu,mump1_p], [nux,nuxmp1_p], hx, x1, [nuy,nuymp1_p], hy, [alphaunn,aunnmp1_p]);
        logPriorDiffAunn = sum(lngampdf(alphaunn,A_./(m+1),1) - lngampdf(alphaunn,A_./m,1));
        %logAccProbMp1 = propLogLklhd - currLogLklhd + logPriorThetamp1 + logPriorDiffAunn - logRetrospPrior - Am_;
        logAccProbMp1 = propLogLklhd - currLogLklhd + logPriorThetamp1 + logPriorDiffAunn - logRetrospPrior - Am_*((m+1)*(log(m+1))^Amlogp_ - m*(log(m))^Amlogp_);
        if rand < exp(logAccProbMp1)
            mp1AccCount = mp1AccCount + 1;
            b=[b,bmp1_p]; mu=[mu,mump1_p]; nux=[nux,nuxmp1_p]; nuy = [nuy,nuymp1_p]; alphaunn=[alphaunn,aunnmp1_p]; %alpha = alphaunn./sum(alphaunn);
            m = m+1;
        end
        propPlogLikelihood = propLogLklhd;
        propMlogLikelihood=0; 

    else % try m-1
        if m > 1
            %choose randomly mixture component candidate for kicking out
            mdraw = randi(m); % take random index
            %[~, minNInd] = min(N); mdraw = minNInd(randi(length(minNInd))); % take random from components with the smallest # of obs
            %MixProb = 1./(N+1); MixProb = MixProb./sum(MixProb); mdraw = find(mnrnd(1,MixProb)); % draw with prob prop 1./(N+1)
            if mdraw ~= m
                btemp = b(:,m); mutemp = mu(:,m); nuxtemp = nux(:,m); nuytemp = nuy(:,m); alphaunntemp = alphaunn(:,m);
                b(:,m)=b(:,mdraw); mu(:,m)=mu(:,mdraw); nux(:,m)=nux(:,mdraw); nuy(:,m) = nuy(:,mdraw); alphaunn(:,m)=alphaunn(:,mdraw);
                b(:,mdraw)=btemp; mu(:,mdraw)=mutemp; nux(:,mdraw)=nuxtemp; nuy(:,mdraw)=nuytemp; alphaunn(:,mdraw)=alphaunntemp;
            end
%            [mumm1_pmsim, d2logPdmumm12sim, bmm1_pmsim, d2logPdbmm12sim, nuxmm1_pmsim, d2logPdnuxmm12sim, nuymm1_pmsim, d2logPdnuymm12sim, aunnmm1_pmsim, d2logPdaunnmm12sim] ...
%             = RetrPriorParams(n, m-1, dx, y, x, x1, hy, hx, b(:,1:m-1), mu(:,1:m-1), nux(:,1:m-1), nuy(:,1:m-1), alphaunn(1:m-1), b(:,m), mu(:,m), nux(:,m), nuy(:,m), alphaunn(:,m), b_, Hb_, mu_, Hmu_, A_, Anuy_, Bnuy_, Anux_, Bnux_);
            [mumm1_pm, d2logPdmumm12, bmm1_pm, d2logPdbmm12, nuxmm1_pm, d2logPdnuxmm12, nuymm1_pm, d2logPdnuymm12, aunnmm1_pm, d2logPdaunnmm12] ...
            = RetrPriorParams(n, m-1, dx, y, x, x1, hy, hx, b(:,1:m-1), mu(:,1:m-1), nux(:,1:m-1), nuy(:,1:m-1), alphaunn(1:m-1), b(:,m), mu(:,m), nux(:,m), nuy(:,m), alphaunn(:,m), b_, Hb_, mu_, Hmu_, A_, Anuy_, Bnuy_, Anux_, Bnux_);
        
            nuxmm1A = GammaAFromMV(nuxmm1_pm, diag(-inv(d2logPdnuxmm12))); nuxmm1B = GammaBFromMA(nuxmm1_pm, nuxmm1A); 
            nuymm1A = GammaAFromMV(nuymm1_pm, diag(-inv(d2logPdnuymm12))); nuymm1B = GammaBFromMA(nuymm1_pm, nuymm1A); 
            aunnmm1A = GammaAFromMV(aunnmm1_pm, diag(-inv(d2logPdaunnmm12))); aunnmm1B = GammaBFromMA(aunnmm1_pm, aunnmm1A); 
            logRetrospPrior = lnnormpdf(mu(:,m),mumm1_pm,-d2logPdmumm12)+lnnormpdf(b(:,m),bmm1_pm,-d2logPdbmm12)...  
                              +sum(lngampdf(nux(:,m),nuxmm1A,nuxmm1B)) + lngampdf(nuy(:,m),nuymm1A,nuymm1B)  + lngampdf(alphaunn(m),aunnmm1A,aunnmm1B); 

            logPriorThetamm1 = lnnormpdf(mu(:,m),mu_,Hmu_) + lnnormpdf(b(:,m),b_,Hb_) + sum(lngampdf(nux(:,m),Anux_,Bnux_)) + lngampdf(nuy(:,m),Anuy_,Bnuy_)  + lngampdf(alphaunn(m),A_./m,1);  

            %JDT caught another silly mistake in the line above: A_./(m+1) was instead of A_m./m
            currLogLklhd = ComputeLogLklhd(n, m, dx, y, x, b, mu, nux, hx, x1, nuy, hy, alphaunn);   
            propLogLklhd = ComputeLogLklhd(n, m-1, dx, y, x, b(:,1:m-1), mu(:,1:m-1), nux(:,1:m-1), hx, x1, nuy(:,1:m-1), hy, alphaunn(1:m-1));
            logPriorDiffAunn = sum(lngampdf(alphaunn(1:m-1),A_./(m-1),1) - lngampdf(alphaunn(1:m-1),A_./m,1));
            %logAccProbMm1 = propLogLklhd - currLogLklhd - logPriorThetamm1 + logPriorDiffAunn + logRetrospPrior + Am_;
            logAccProbMm1 = propLogLklhd - currLogLklhd - logPriorThetamm1 + logPriorDiffAunn + logRetrospPrior - Am_*((m-1)*(log(m-1))^Amlogp_ - m*(log(m))^Amlogp_);
            if rand < exp(logAccProbMm1)
                mm1AccCount = mm1AccCount + 1;
                b=b(:,1:m-1); mu=mu(:,1:m-1); nux=nux(:,1:m-1); nuy = nuy(:,1:m-1); alphaunn=alphaunn(:,1:m-1); %alpha = alphaunn./sum(alphaunn);
                m=m-1;
            else
%                if mdraw ~= m
%                     b(:,mdraw)=b(:,m); mu(:,mdraw)=mu(:,m); nux(:,mdraw)=nux(:,m); nuy(:,mdraw) = nuy(:,m); alphaunn(:,mdraw)=alphaunn(:,m);
%                     b(:,m)=btemp; mu(:,m) = mutemp ; nux(:,m) = nuxtemp; nuy(:,m) = nuytemp; alphaunn(:,m) = alphaunntemp;
%                end

            end
            propMlogLikelihood = propLogLklhd;
            propPlogLikelihood=0;
        else
            currLogLklhd=0;  propMlogLikelihood=0; propPlogLikelihood=0;
        end
    end

%% end of retrospective sampling for drawing m, %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

