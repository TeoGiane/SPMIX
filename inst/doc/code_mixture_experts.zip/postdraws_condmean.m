% Posterior sample of conditional density values
% p(y_i|x_i) = \sum_{j=1}^m  alpha(j)\exp[ -0.5 (x_i-mu(j))' Hx_j (x_i-mu(j))] *
% \phi(y_i,x1_i'b_j,(hy*nuy(j))^-1) /...
% \sum_{j=1}^m   alpha(j) \exp[ -0.5 (x_i-mu(j))' Hx_j (x-mu(j))]
% where x1 = [1;x];
% Hx_j = diag(hx(1)*nux(1,j),...,hx(dx}*nux(dx,j))

function condmeandraws = postdraws_condmean(x, x1,...
                         sim_b, sim_mu, sim_alphaunn, sim_hy, sim_hx, sim_nuy, sim_nux, sim_m, ...
                         Nsim, thin_step)
    
n = length(x(1,:));
dx = length(x(:,1));
indc = thin_step:thin_step:Nsim;
condmeandraws = zeros(n,length(indc));
draw = 1;
for sim = indc
    m = sim_m(sim);
    b = sim_b(:,1:m,sim);
    mu = sim_mu(:,1:m,sim);
    alpha = sim_alphaunn(1:m,sim)'./sum(sim_alphaunn(1:m,sim));
    hy = sim_hy(:,sim); 
    hx = sim_hx(:,sim); 
    nuy = sim_nuy(1:m,sim)'; 
    nux = sim_nux(:,1:m,sim);
    condmeandraws(:,draw) = meanycondxparam(x, x1, b, mu, alpha, hy, hx, nuy, nux, m);
    draw = draw + 1;
end
