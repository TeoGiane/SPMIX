function se = bmse(x, M)
%computes a standard error for the sample path mean using batching
n = length(x);
rem = mod(n, M);
bm = mean(reshape(x(1:n-rem), M, (n-rem)/M));
ACF = corrcoef(bm(1:length(bm)-1),bm(2:length(bm)));%xcorr(bm, 1, 'coeff')%[ACF, Lags, Bounds] = autocorr(bm, 1);
r = ACF(1,2);%ACF(1);%r = ACF(2);

se = std(bm) * sqrt((1+r)/(1-r)) / sqrt(length(bm));