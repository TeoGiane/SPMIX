%Prior draw in mixreg model
function [b, mu, alphaunn, hy, hx, nuy, nux] = PriorDraw(m, b_, invHb_, mu_, invHmu_, A_, Ahy_, Bhy_, Ahx_, Bhx_,...
    Anuy_, Bnuy_, Anux_, Bnux_)
b = mvnrnd(b_',invHb_, m)';
mu = mvnrnd(mu_',invHmu_, m)';
alphaunn = gamrnd(ones(1,m).*A_./m, 1);  %alpha =  alphaunn./sum(alphaunn); % Dirichlet draw = normalized gamma
hy = gamrnd(Ahy_, 1./Bhy_).^2;% should be inv-G(A,B) for s2 \prop to s2^{-A-1}exp{-B/s2}
hx = gamrnd(Ahx_, 1./Bhx_).^2;
nuy = gamrnd(Anuy_, 1./Bnuy_, 1, m);
nux = gamrnd(repmat(Anux_,1,m), repmat(1./Bnux_,1,m));
