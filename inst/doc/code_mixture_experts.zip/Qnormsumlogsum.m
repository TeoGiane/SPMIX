function [aexpQnorm, sumlogsumkaexpQ] = Qnormsumlogsum(Q,alpha)        

maxQ = max(Q,[],2);  
expQnorm = exp(bsxfun(@minus, Q, maxQ)); 
aexpQnorm = bsxfun(@times, expQnorm, alpha);
sumaexpQnorm = sum(aexpQnorm,2); 
aexpQnorm = bsxfun(@rdivide, aexpQnorm, sumaexpQnorm);
sumlogsumkaexpQ = sum(log(sumaexpQnorm)+maxQ);
