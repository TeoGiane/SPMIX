function [Jacob, Hess] = DerHessLogLklhdPrior_m(n, m, dx, y, x, x1, hy, hx, b, mu, nux, nuy, alphaunn, b_, Hb_, mu_, Hmu_, A_, Anuy_, Bnuy_, Anux_, Bnux_)
%Derivarive of Log(L*Pi) w.r.t. m^th component with positive elements,
%e.g., nux(d,m)=exp(z_{nuxind}), replaced by exp(.)
 
Hess = zeros(3*dx+3,3*dx+3);
Jacob = zeros(3*dx+3,1);
Q = ComputeQ(n, m, dx, x, mu, nux, hx);
[aexpQnorm, sumlogsumkaexpQ] = Qnormsumlogsum(Q,alphaunn);       
Eps = bsxfun(@minus, y', reshape(sum(reshape(bsxfun(@times, repmat(x1',1,m), reshape(b,1,m*(dx+1)))', dx+1, m*n)),m,n)'); 
QyQloganormm = ComputeQyQloganormmp1(Eps, nuy, hy, Q, alphaunn);
phil1c = QyQloganormm-aexpQnorm(:,m);
Hmp1x_mum = bsxfun(@times,bsxfun(@minus,x,mu(:,m)), nux(:,m).*hx);
Jacob(dx+2:2*dx+1,1) = Hmp1x_mum * phil1c + Hmu_*(mu_-mu(:,m)); % dlogPdmum
Hmp1 = diag(nux(:,m).*hx);
d2logPdmum2 = -sum(phil1c)*Hmp1 + sum(bsxfun(@times, xxtvec(Hmp1x_mum'), reshape(phil1c.*(1-aexpQnorm(:,m) - QyQloganormm), 1,1,n)),3) - Hmu_;
Hess(dx+2:2*dx+1,dx+2:2*dx+1) = d2logPdmum2;


kappa = -0.5* bsxfun(@times,bsxfun(@minus,x,mu(:,m)).^2, hx);
Jacob(2*dx+2:3*dx+1,1) = (kappa * (QyQloganormm - aexpQnorm(:,m)) + (Anux_- 1)./nux(:,m) - Bnux_).*nux(:,m); % dlogPdnuxm.*nux(:,m) - as we reparameterize in log(nux)
d2logPdnuxm = sum(bsxfun(@times, xxtvec(kappa'), reshape((QyQloganormm - aexpQnorm(:,m)).*(1-aexpQnorm(:,m)-QyQloganormm), 1,1,n)),3) - diag((Anux_- 1)./(nux(:,m).^2));
Hess(2*dx+2:3*dx+1,2*dx+2:3*dx+1) = bsxfun(@times, d2logPdnuxm, nux(:,m)) + diag(Jacob(2*dx+2:3*dx+1,1));

Jacob(1:dx+1,1) = (hy*nuy(m)).*(x1 * (QyQloganormm.*Eps(:,m))) + Hb_*(b_-b(:,m)); % dlogPdbm
Hess(1:dx+1,1:dx+1) = -(hy*nuy(m)).*sum(bsxfun(@times, xxtvec(x1'), reshape(QyQloganormm.*(1-(hy*nuy(m)).*(Eps(:,m).^2).*(1-QyQloganormm)), 1,1,n)),3) - Hb_;




kappay = -0.5* (Eps(:,m).^2)*hy;
Jacob(3*dx+2) = (sum((kappay+0.5./nuy(:,m)) .* QyQloganormm) + (Anuy_- 1)./nuy(:,m) - Bnuy_)*nuy(:,m);%dlogPdnuym*nuy(:,m)
d2logPdnuym2 = sum(   QyQloganormm.*(  ((kappay+0.5./nuy(:,m)).^2).*(1-QyQloganormm) -0.5./ nuy(:,m).^2)) - diag((Anuy_- 1)./(nuy(:,m).^2));
Hess(3*dx+2,3*dx+2) = (d2logPdnuym2 + Jacob(3*dx+2))* nuy(:,m);
 



Jacob(3*dx+3)= (sum((QyQloganormm - aexpQnorm(:,m))./alphaunn(m)) +  (A_./m-1)./alphaunn(m) - 1)*alphaunn(m);  % dlogPdaunnm * alphaunn(m)
d2logPdaunnm2 = sum(  (aexpQnorm(:,m).^2 - QyQloganormm.^2)./(alphaunn(m).^2)) -  (A_./(m)-1)./(alphaunn(m).^2);
Hess(3*dx+3,3*dx+2) = (d2logPdaunnm2 + Jacob(3*dx+3))* alphaunn(m);

if any(isnan(Jacob(:)))  || any(isinf(Jacob(:))) || any(imag(Jacob(:)))
    stopphere = 1;
end
%Jacob'


