% Conditional density values

function condpdf = pdfycondxparam(y, x, x1, b, mu, alphaunn, hy, hx, nuy, nux, m)
            
n = length(y);
dx = length(x(:,1));
Q = ComputeQ(n, m, dx, x, mu, nux, hx);
[aexpQnorm, ~] = Qnormsumlogsum(Q,alphaunn);
%aexpQ = bsxfun(@times, exp(Q), alphaunn);
%aexpQnorm = bsxfun(@rdivide, aexpQ, sum(aexpQ,2));
Qy = reshape(sum(reshape(bsxfun(@times, repmat(x1',1,m), reshape(b,1,m*(dx+1)))', dx+1, m*n)),m,n)';
Qy = bsxfun(@minus, Qy, y');
Qy = bsxfun(@times, exp(-0.5*bsxfun(@times, Qy.^2, nuy.*hy)), sqrt(nuy.*hy)./sqrt(2*pi));
condpdf = sum(aexpQnorm.*Qy,2);
