% runs Monte Carlo reported in Norets and Pati (2016)
% changing dx (dimension of x) and un/commenting different DGPs below
% will produce different raws in Table 1.  Current settings are for raw 3
% Calls to R package np are commentred out so the np results will not be produced
% uncommetning calls to np would require installation of R, np package in R, 
% setting paths for R, changing paths in enclosed "npest.r"
% and making sure R can be called from matlab using:
% system('R CMD BATCH npest.r');
clear; close all;

if isunix
    % Code to run on Linux plaform - if run on linux put a path to matlab
    % files here:
    path(path,'/home/anorets/denregcode')
elseif ispc
    % Code to run on Windows platform
else
    disp('Cannot recognize platform')
end

%initialization for estimation from art data or joint distribution tests
jdt_flag = 0;
Nsim = 10000;% # of MCMC iterations per simulator run
progress_step = 1000;
burnin = ceil(Nsim*0.1);

FlagRunNPkernelEst = 1;

mc_len = 30;% # of of Monte Carlos (simulated datasets on which MCMC estimation is done)
rmse=zeros(1,mc_len);
mae=zeros(1,mc_len);
rmsenp=zeros(1,mc_len);
maenp=zeros(1,mc_len);

for mc_ind = 1:mc_len
%initialize random var generator
rng(135462+mc_ind);
%rng(235462);


% %%%%%%%%    DGP - model at a draw from prior conditional on a given m0   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% x = 1*(-1+2.*rand(dx,n)); x1 = [ones(1,n); x]; 
% m0 = 3; % DGP # of mixture components
% % DGP params = prior draw
% [b0, mu0, alpha0, hy0, hx0, nuy0, nux0] = PriorDraw(m0, b_, invHb_, mu_, invHmu_, A_, Ahy_, Bhy_, Ahx_, Bhx_, Anuy_, Bnuy_, Anux_, Bnux_);
% [y, s0, mult_draw0, N0]=DrawYScondParams(x,x1,b0, mu0, alpha0, hy0, hx0, nuy0, nux0);
% dgpcpdfeval = @(ypdf,xpdf) pdfycondxparam(ypdf, xpdf, [ones(1,length(xpdf(1,:)));xpdf], b0, mu0, alpha0, hy0, hx0, nuy0, nux0, m0);
%End: Use this for jdt and data generated from prior %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%% DGP in (6.3) from Norets, Pelenis %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% n = 1000;
% dx = 1;
% x = zeros(dx,n);
% x(1,:) = rand(1,n);%normrnd(0.5, 1./sqrt(12),1,n);% 
% rq = exp(-2*x(1,:)); 
% sdgp = rand(1,n) < rq;
% y = normrnd( sdgp.*x(1,:) + (1-sdgp).*x(1,:).^4, sdgp.*0.1 + (1-sdgp).*0.2);
% for dxind = 2:dx % to make sure in MC with different dx values the data values are the same up to the smallest dx
%     x(dxind,:) = rand(1,n);%normrnd(0.5, 1./sqrt(12),1,n);% 
% end
% x1 = [ones(1,n); x]; 
% dgpNP63pdfeval = @(y,x) exp(-2*x(1,:)).*normpdf(y,x(1,:),0.1) + (1-exp(-2*x(1,:))).*normpdf(y,x(1,:).^4,0.2); 
% dgpcpdfeval = dgpNP63pdfeval;
% % grids for plotting and rmse mae computing
% miny = min(y); maxy = max(y); 
% ygridPlot = miny:(maxy-miny)/100:maxy;
% xgrid1d = [0.1, 0.5, 0.9];
% xgridRMSE = GridNDLin(xgrid1d, dx);
% xgridPlot = [xgrid1d; xgrid1d(ceil(length(xgrid1d)/2))*ones(dx-1,length(xgrid1d))];
%End: DGP in (6.3) from Norets, Pelenis %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%% DGP normal heteroskedastic density, similar to Villani Kohn Giordani 2007, Sec 4.3%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% n = 1000;
% dx = 2;
% delta = ones(1,dx)./dx;  sdgp = 1;
% x = -1+2*rand(dx,n); x1 = [ones(1,n); x]; 
% y = normrnd( zeros(1,n), sdgp*exp(delta*x));
% dgpVKGcpdfeval = @(y,x) normpdf(y,0,sdgp*exp(delta*x)); 
%  % Define grids on x and y for plotting
% xgrid1d = [-0.5, 0, 0.5]; 
%  xgridPlot = [xgrid1d; xgrid1d(ceil(length(xgrid1d)/2))*ones(dx-1,length(xgrid1d))];
% miny = min(y); maxy = max(y); 
% ygridPlot = miny:(maxy-miny)/100:maxy;
%  % Define finer grids for computing RMSE and MAE
% xgridRMSE = GridNDLin(xgrid1d, dx);
% ygridRMSE = ygridPlot;
% dgpcpdfeval = dgpVKGcpdfeval;

%End: DGP %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%% DGP in (6.4) from Norets, Pelenis and Hall et al (1999)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
n = 1000;
dx = 1;
x = -1+2*rand(dx,n); x1 = [ones(1,n); x]; 
indU2 = rand(1,n) < 0.5;
eps = zeros(1,n);
eps(1,indU2) = 1-sqrt(rand(1,sum(indU2)));
eps(1,~indU2) = sqrt(rand(1,sum(~indU2)))-1;% so eps_i \sim (1-|eps_i|)*1[-1<eps_i<1]
y = sin(pi*x)+eps;
dgpNP64pdfeval = @(y,x) (1-abs(y-sin(pi*x))).* (1>abs(y-sin(pi*x))); 
% Define grids on x and y for plotting
xgridlenPlot = 4; 
xgridPlot = [-0.8, -0.3, 0, 0.3, 0.8];
miny = min(y); maxy = max(y); 
ygridPlot = miny:(maxy-miny)/100:maxy;
%  % Define finer grids for computing RMSE and MAE
xgridRMSE = -1:0.05:1;
ygridRMSE = -2:0.05:2;
dgpcpdfeval = dgpNP64pdfeval;
%End: DGP in (6.4) from Norets, Pelenis %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




%Save data in text file for np in R
dataforR=[x' y'];
save 'EstDataForR.txt' dataforR -ascii

%Data dependent prior/empirical bayes
[xmean, xvar, olsb, olserrvar, b_, Hb_, mu_, Hmu_, A_, Ahy_, Bhy_, Ahx_, Bhx_, Anuy_, Bnuy_, Anux_, Bnux_, Am_, Amlogp_] = EBayesDefaultPriorParamsOrig(y,x,x1);
%prior_pred_analysis
%[xmean, xvar, olsb, olserrvar, b_, Hb_, mu_, Hmu_, A_, Ahy_, Bhy_, Ahx_, Bhx_, Anuy_, Bnuy_, Anux_, Bnux_, Am_, Amlogp_] = EBayesDefaultPriorParams(y,x,x1);

%Initialize parameters
m0 = 1;
mu0 = xmean;
b0 = olsb; 
hy0 = 1./sqrt(olserrvar);%gamrnd(Ahy_, 1./Bhy_);%hy = 1;
nuy0 = 1./(olserrvar*hy0);
hx0 = 1./sqrt(xvar);%ones(dx,1);
nux0 = 1./(xvar.*hx0);
alphaunn0 = gamrnd(ones(1,m0).*A_./m0,1); alpha0=alphaunn0/sum(alphaunn0); 


% Call posterior simulator %%%%%%%%%%%%%%%%%%%%%%%%%% 

[sim_b, sim_mu, sim_alphaunn, sim_hy, sim_hx, sim_nuy, sim_nux, sim_m] ...
         = post_simulator4(y, x, x1,...
                            b0, mu0, alphaunn0, hy0, hx0, nuy0, nux0, m0,...
                            b_, Hb_, mu_, Hmu_, A_, Ahy_, Bhy_, Ahx_, Bhx_, Anuy_, Bnuy_, Anux_, Bnux_, Am_, Amlogp_,...
                            Nsim, jdt_flag, progress_step);
                      
                        
% [sim_b, sim_mu, sim_alphaunn, sim_hy, sim_hx, sim_nuy, sim_nux, sim_m] ...
%          = post_simulator3(y, x, x1,...
%                          b_, Hb_, mu_, Hmu_, A_, Ahy_, Bhy_, Ahx_, Bhx_, Anuy_, Bnuy_, Anux_, Bnux_, Am_, Amlogp_,...
%                          Nsim, jdt_flag, progress_step);
%                         
                        
                        
%%%%%%%%%%  plot priors and posteriors for parameters, uncomment for jdt                  
% plot_test_postsimout; 
%%%%%%%%%


% %plot cond pdf's post mean and q and 1-q quantiles
%  q = 0.0001;
%  plotpostpdfdraws(100, ygridPlot, xgridPlot, sim_b, sim_mu, sim_alphaunn, sim_hy, sim_hx, sim_nuy, sim_nux, sim_m, Nsim, 10, q);
%  plotdgpcpdf(100, ygridPlot, xgridPlot, dgpcpdfeval);
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                  
%%%%%%%%% Plot prior and true dgp                      
% [priorsim_b, priorsim_mu, priorsim_alphaunn, priorsim_hy, priorsim_hx, priorsim_nuy, priorsim_nux, priorsim_m] ...
%          = prior_simulator(b_, Hb_, mu_, Hmu_, A_, Ahy_, Bhy_, Ahx_, Bhx_, Anuy_, Bnuy_, Anux_, Bnux_, Am_, Amlogp_, Nsim); 
% plotpostpdfdraws(101, ygridPlot, xgridPlot, priorsim_b, priorsim_mu, priorsim_alphaunn, priorsim_hy, priorsim_hx, priorsim_nuy, priorsim_nux, priorsim_m, Nsim, 1, q);
% plotdgpcpdf(101, ygridPlot, xgridPlot, dgpcpdfeval); 
% 
% if FlagRunNPkernelEst
%     plotnpcpdf(101, ygridPlot, xgridPlot, 1);
% end

%legend('post mean','0.0001 quantile', '0.9999 quantile', 'true', 'kernel'); xlabel('y'); ylabel('p(y|x)')

% compute RMSE and MAE as in Norets and Pelenis (2014)
[rmse(mc_ind), mae(mc_ind)] = rmsemaepostcpdf(dgpcpdfeval, ygridPlot, xgridRMSE, sim_b(:,:,burnin:end), sim_mu(:,:,burnin:end), sim_alphaunn(:,burnin:end), sim_hy(:,burnin:end), sim_hx(:,burnin:end), sim_nuy(:,burnin:end), sim_nux(:,:,burnin:end), sim_m(:,burnin:end), Nsim-burnin+1, 1)
% the following lines call r package np, this would require changing
% paths  in npest.r, installing r and np package, setting paths for r, etc

if FlagRunNPkernelEst
    tic
    [rmsenp(mc_ind), maenp(mc_ind)] = rmsemaenpcpdf(dgpcpdfeval, ygridPlot, xgridRMSE, 1)
    msg = sprintf('NP Time = %d', toc); display(msg);
end

 tabrmse = [mean(rmse(1:mc_ind)), mean(rmsenp(1:mc_ind)), mean(rmse(1:mc_ind)-rmsenp(1:mc_ind)), mean(rmse(1:mc_ind)<rmsenp(1:mc_ind)), sqrt(length(rmse(1:mc_ind)))*mean(rmse(1:mc_ind)-rmsenp(1:mc_ind))./std(rmse(1:mc_ind)-rmsenp(1:mc_ind))]
 tabmae = [mean(mae(1:mc_ind)), mean(maenp(1:mc_ind)), mean(mae(1:mc_ind)-maenp(1:mc_ind)), mean(mae(1:mc_ind)<maenp(1:mc_ind)),    sqrt(length(mae(1:mc_ind)))*mean(mae(1:mc_ind)-maenp(1:mc_ind))./std(mae(1:mc_ind)-maenp(1:mc_ind))]


end

% tabrmse = [mean(rmse), mean(rmsenp), mean(rmse-rmsenp), mean(rmse<rmsenp), sqrt(length(rmse))*mean(rmse-rmsenp)./std(rmse-rmsenp)]
% tabmae = [mean(mae), mean(maenp), mean(mae-maenp), mean(mae<maenp),    sqrt(length(mae))*mean(mae-maenp)./std(mae-maenp)]






%save('est11_23_16_dgp64.mat');
