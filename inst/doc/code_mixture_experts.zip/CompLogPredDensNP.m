function logscore = CompLogPredDensNP(pred_y, pred_x, flagRecalc)

if flagRecalc
    dataforRpred=[pred_x' pred_y'];
    save 'PredDataForR.txt' dataforRpred -ascii;
%    path(path,'C:/Program Files/R/R-3.2.2/bin');
    
    system('R CMD BATCH npest.r'); 
end

npcpdfvals = importdata('cdensPredFromR.txt');
logscore = sum(log(npcpdfvals));          

