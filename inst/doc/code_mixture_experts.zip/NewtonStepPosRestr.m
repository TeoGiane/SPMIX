function step = NewtonStepPosRestr(h, v) 
step = min(0.9*min(h(v>0)./v(v>0)),0.5);
if isempty(step) 
    step=0.9; 
end;
