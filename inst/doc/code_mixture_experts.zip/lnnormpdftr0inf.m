%returns logarithm of the normal pdf truncated to (0,infinity)
function res = lnnormpdftr0inf(x,mu,sd)
res = -0.5*sum(((x-mu).^2)./sd.^2) - 0.5*length(mu)*log(2*pi) -sum(log(sd)) - sum(log(1-normcdf(zeros(size(mu)), mu, sd)));