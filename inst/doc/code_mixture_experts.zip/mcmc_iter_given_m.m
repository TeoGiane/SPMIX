% MCMC update of 
% (b, mu, alphaunn, hy, hx, nuy, nux) | m 


function [b, mu, alphaunn, hy, hx, nuy, nux, N, Q, aexpQnorm, sumlogsumkaexpQ, bAccCount, muAccCount, alphaAccCount, hyAccCount,  hxAccCount, nuxAccCount] ...
         = mcmc_iter_given_m(y, x, x1, x1x1t, x1ty, dx, n,...
                                b, mu, alphaunn, hy, hx, nuy, nux, m, Q, aexpQnorm, sumlogsumkaexpQ,...
                                bAccCount, muAccCount, alphaAccCount, hyAccCount,  hxAccCount, nuxAccCount, ...
                                b_, Hb_, mu_, Hmu_, A_, Ahy_, Bhy_, Ahx_, Bhx_, Anuy_, Bnuy_, Anux_, Bnux_, Am_, Amlogp_,Hb_b_)


NewtonStep09 = @(argmu,v) 0.9;
Nnewtiter = 100; NewtonTol = 10^-10; %Newton method params
rwVarAdj = 0.5;

nonconvcount = 0;


alpha = alphaunn./sum(alphaunn);

% Block for s %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Q = ComputeQ(n, m, dx, x, mu, nux, hx);
%[aexpQnorm, sumlogsumkaexpQ] = Qnormsumlogsum(Q,alpha);
if m> 1
    Qy = reshape(sum(reshape(bsxfun(@times, repmat(x1',1,m), reshape(b,1,m*(dx+1)))', dx+1, m*n)),m,n)';
    % There was a bug was in the line above, instead of ",m,n)'" I had ",n,m)", caught with help from JDT
    Qy = bsxfun(@minus, Qy, y');
    Qy = bsxfun(@times, Qy, sqrt(nuy.*hy));
    Qa = -0.5*Qy.^2+Q;
    expQa = exp(bsxfun(@minus, Qa, max(Qa,[],2)));
    expQa = bsxfun(@times, expQa, sqrt(nuy));
    [s, mult_draw] = SCondParamDraw(expQa, alpha); 
else
    s = ones(n,1);
    mult_draw = ones(1,n);
end
N = sum(mult_draw,2);  
     
% block for betaj %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for j = 1:m
   Precbj = Hb_ + sum(x1x1t(:,:,logical(mult_draw(j,:))),3).*(hy*nuy(j));
   varbj = inv(Precbj);
   Meanbj =  varbj*(Hb_b_+ sum(x1ty(:,logical(mult_draw(j,:))),2).*(hy*nuy(j)));
   b(:,j) = mvnrnd(Meanbj, varbj)';
end

% block for hy, 4 lines for cond conjugate prior are commented out,  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%eps2 = (y-sum(b(:,s).*x1)).^2;
%Ahy = Ahy_ + n/2;
%Bhy = Bhy_ + 0.5*sum(eps2.*nuy(1,s));
%hy = gamrnd(Ahy, 1./Bhy);
    
eps2 = (y-sum(b(:,s).*x1)).^2;
Ahy_prp = Ahy_*0.5 + n/2;
Bhy_prp = 0.5*sum(eps2.*nuy(1,s));
hy_p = gamrnd(Ahy_prp, 1./Bhy_prp);
if rand < exp(-Bhy_*(hy_p.^0.5-hy.^0.5))
    hy = hy_p;
    hyAccCount = hyAccCount + 1;
end



% block for nuy %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Anuy = Anuy_ + N'/2;
Bnuy = Bnuy_ + 0.5*eps2*mult_draw'.*hy;
nuy = gamrnd(Anuy, 1./Bnuy);
    
     
   
%  Block for alpha, Newton method - seems to work and JDT pass 
if m > 1
    Np = (A_./m)'+N-1; % here was another bug detected by jdt: forgot to subtract 1
    %[aexpQnorm, sumlogsumkaexpQ] = Qnormsumlogsum(Q,alpha);
    DerivAlpha = @(argx) DerivativesAlpha([argx;1-sum(argx)]', Np, Q, m, []);
    [NewtonStatusAlpha, Nxalpha, NHalpha] = NewtonMethod(alpha(1:m-1)', DerivAlpha, @NewtonStepAlpha, NewtonTol, Nnewtiter);
    if NewtonStatusAlpha == 0
        prpVar = -inv(NHalpha);
        alpha_p = [mvnrnd(Nxalpha',prpVar),0]; 
        alpha_p(m) = 1-sum(alpha_p(1:m-1));
        if alpha_p > 0
            [aexpQnorm_p, sumlogsumkaexpQ_p] = Qnormsumlogsum(Q,alpha_p);
            logLalpha = sum(Np'.*log(alpha)) - sumlogsumkaexpQ;
            logLalpha_p = sum(Np'.*log(alpha_p)) - sumlogsumkaexpQ_p;
            AccProb = exp(logLalpha_p - logLalpha ...
                      -0.5*(alpha_p(1:m-1)-Nxalpha')*NHalpha*(alpha_p(1:m-1)-Nxalpha')'...
                      +0.5*(alpha(1:m-1)-Nxalpha')*NHalpha*(alpha(1:m-1)-Nxalpha')' );
             if rand < AccProb
                 alpha = alpha_p;
                 sumlogsumkaexpQ = sumlogsumkaexpQ_p;
                 aexpQnorm = aexpQnorm_p;
                 alphaAccCount = alphaAccCount + 1;
             end
        end
     else % NewtonStatusAlpha 1 or 2 
        [~,HessAlpha]= DerivativesAlpha(alpha, Np, Q, m, aexpQnorm);
        HessAlpha = Negadefinize(HessAlpha);
        RWVar = -rwVarAdj*inv(HessAlpha);
        RWPrec = -HessAlpha./rwVarAdj;

        [~,err] = cholcov(RWVar);
        if err ~= 0
            RWVar = posidefinize(RWVar);
            RWPrec = inv(RWVar);
        end

        alpha_p = [mvnrnd(alpha(1:m-1),RWVar),0]; 
        alpha_p(m) = 1-sum(alpha_p(1:m-1));
        if all(alpha_p > 0)
            [aexpQnorm_p, sumlogsumkaexpQ_p] = Qnormsumlogsum(Q,alpha_p);
            [~,HessAlpha]= DerivativesAlpha(alpha_p, Np, Q, m, aexpQnorm_p);
            HessAlpha = Negadefinize(HessAlpha);
            RWPropPrec = -HessAlpha./rwVarAdj;
            logLalpha = sum(Np'.*log(alpha)) - sumlogsumkaexpQ;
            logLalpha_p = sum(Np'.*log(alpha_p)) - sumlogsumkaexpQ_p;
            AccProb = exp(logLalpha_p - logLalpha - lnnormpdf(alpha_p(1:m-1)',alpha(1:m-1)',RWPrec) + lnnormpdf(alpha(1:m-1)',alpha_p(1:m-1)',RWPropPrec));
            if rand < AccProb
                 alpha = alpha_p;
                 sumlogsumkaexpQ = sumlogsumkaexpQ_p;
                 aexpQnorm = aexpQnorm_p;
                 alphaAccCount = alphaAccCount + 1;
            end
        end        
    end
else
    alpha = 1;
    alphaAccCount = alphaAccCount + 1;
end
%%% end block for alpha %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    

% Draw unnormalized alpha%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
    alphaunn = alpha*gamrnd(A_,1); % draw from conditional posterior since alpha is a priori independent from sum(alphaunn) and likelihood depends only on alpha=alphaunn/sum(alphaunn)
% end Draw unnormalized alpha%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   



%%%%%   Block for mu %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
for j=1:m
    Hjdiag = nux(:,j).*hx;
    oldQj = Q(:,j);
    if N(j) == 0
        sum_x = zeros(dx,1);
%           muj_pm = mean(x,2);
    else
         sum_x = sum(x(:,logical(mult_draw(j,:))),2); 
%            muj_pm = sum_x ./ N(j);% initialize with average of covariates
    end
    %muj_pm = mu(:,j);% will invalidate MH if Newton does not converge, could use commented lines above instead
    Hjsum_x = sum_x.*Hjdiag;
    DerivMuj = @(argx) DerivativesMuj(argx, x, Hjdiag, Hjsum_x, Q, j, alpha, N, mu_, Hmu_);
    [NewtonStatusMuj, muj_pm, NHmuj] = NewtonMethod(mu(:,j), DerivMuj, NewtonStep09, NewtonTol, Nnewtiter);

    if NewtonStatusMuj == 0
        prpVar = -inv(NHmuj);
        muj_p = mvnrnd(muj_pm,prpVar)'; 
        x_mj = bsxfun(@minus, x, muj_p);
        Hjx_mj = bsxfun(@times, x_mj, Hjdiag);
        Q(:,j) = -0.5*sum(x_mj.*Hjx_mj,1)';
        [aexpQnorm_p, sumlogsumkaexpQ_p] = Qnormsumlogsum(Q,alpha);
        %again jdt helped to catch missing "*N(j)" in the following line
        AccProb = exp(  -0.5*sum((muj_p.^2 - mu(:,j).^2).*Hjdiag)*N(j) +(muj_p - mu(:,j))'*Hjsum_x ...
                  - sumlogsumkaexpQ_p + sumlogsumkaexpQ ...
                  -0.5*(muj_p-muj_pm)'*NHmuj*(muj_p-muj_pm)...
                  +0.5*(mu(:,j)-muj_pm)'*NHmuj*(mu(:,j)-muj_pm) ...
                  -0.5*(muj_p-mu_)'*Hmu_*(muj_p-mu_)...
                  +0.5*(mu(:,j)-mu_)'*Hmu_*(mu(:,j)-mu_) );
         if rand < AccProb
             mu(:,j) = muj_p;
             muAccCount(j) = muAccCount(j) + 1;
             sumlogsumkaexpQ = sumlogsumkaexpQ_p;
             aexpQnorm = aexpQnorm_p;
         else
             Q(:,j) = oldQj;
         end

     else % NewtonStatusAlpha 1 or 2 
        [~,HessMuj]= DerivativesMuj(mu(:,j), x, Hjdiag, Hjsum_x, Q, j, alpha, N, mu_, Hmu_);
        HessMuj = Negadefinize(HessMuj);
        RWPrec = -HessMuj./rwVarAdj;
        RWVar = inv(RWPrec);

        muj_p = mvnrnd(mu(:,j),RWVar)'; 

        x_mj = bsxfun(@minus, x, muj_p);
        Hjx_mj = bsxfun(@times, x_mj, Hjdiag);
        Q(:,j) = -0.5*sum(x_mj.*Hjx_mj,1)';
        [aexpQnorm_p, sumlogsumkaexpQ_p] = Qnormsumlogsum(Q,alpha);
        HessMuj = - sum(bsxfun(@times, xxtvec(Hjx_mj'), reshape(aexpQnorm_p(:,j) - aexpQnorm_p(:,j).^2, 1,1,n)),3) ...
                      + diag( (sum(aexpQnorm_p(:,j))-N(j)) .*Hjdiag) - Hmu_;
        HessMuj = Negadefinize(HessMuj);
        RWPropPrec = -HessMuj./rwVarAdj;
        AccProb = exp( -0.5*sum((muj_p.^2 - mu(:,j).^2).*Hjdiag)*N(j) +(muj_p - mu(:,j))'*Hjsum_x ...
                      -sumlogsumkaexpQ_p + sumlogsumkaexpQ ...
                      -0.5*(muj_p-mu_)'*Hmu_*(muj_p-mu_) + 0.5*(mu(:,j)-mu_)'*Hmu_*(mu(:,j)-mu_) ...
                      -lnnormpdf(muj_p,mu(:,j),RWPrec) + lnnormpdf(mu(:,j),muj_p,RWPropPrec));
        if rand < AccProb
             mu(:,j) = muj_p;
             sumlogsumkaexpQ = sumlogsumkaexpQ_p;
             aexpQnorm = aexpQnorm_p;
             muAccCount(j) = muAccCount(j) + 1;
        else
             Q(:,j) = oldQj; 
        end
    end        
end
   
% end block for mu  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
    

%%%   Block for nux_j, j=1,m , Newton method for proposal%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for j=1:m
    oldQj = Q(:,j);
    x_mj = bsxfun(@minus, x, mu(:,j));
    r_j05 = 0.5*bsxfun(@times, x_mj.^2,hx); 
    if N(j) == 0
%           sum_x = zeros(dx,1);
%           nuj_pm = hx./var(x,1,2);
        sum_rjsieqj05 = 0;
    else
%           nuj_pm = hx./(var(x(:,logical(mult_draw(j,:))),1,2));
        sum_rjsieqj05 = sum(r_j05(:,logical(mult_draw(j,:))),2);
    end
    %nuj_pm = nux(:,j);% will invalidate MH if Newton does not converge

    DerivNuxj = @(argx) DerivativesNuxj(argx, x, hx, x_mj, Q, j, alpha, sum_rjsieqj05, r_j05, Anux_, Bnux_);
    [NewtonStatusNuxj, nuxj_pm, NHnuxj] = NewtonMethod(nux(:,j), DerivNuxj, @NewtonStepPosRestr, NewtonTol, Nnewtiter);

    if NewtonStatusNuxj == 0
        prpVar = -inv(NHnuxj);
        nuxj_p = mvnrnd(nuxj_pm,prpVar)';
        if all(nuxj_p > 0)
            Hjdiag = nuxj_p.*hx;
            Hjx_mj = bsxfun(@times, x_mj, Hjdiag);
            Q(:,j) = -0.5*sum(x_mj.*Hjx_mj,1)';
            [aexpQnorm_p, sumlogsumkaexpQ_p] = Qnormsumlogsum(Q,alpha);
            AccProb = exp(  (sum_rjsieqj05+Bnux_)'*(nux(:,j) - nuxj_p) ...
                      + (Anux_- 1)'* (log(nuxj_p)-log(nux(:,j))) ...        
                      - sumlogsumkaexpQ_p + sumlogsumkaexpQ ...
                      -0.5*(nuxj_p-nuxj_pm)'*NHnuxj*(nuxj_p-nuxj_pm)...
                      +0.5*(nux(:,j)-nuxj_pm)'*NHnuxj*(nux(:,j)-nuxj_pm));
            if rand < AccProb 
                 nux(:,j) = nuxj_p;
                 nuxAccCount(j) = nuxAccCount(j) + 1;
                 aexpQnorm = aexpQnorm_p;
                 sumlogsumkaexpQ = sumlogsumkaexpQ_p;
            else
                Q(:,j) = oldQj;
            end
        end
    else % NewtonStatusNuxj 1 or 2 
         [~,HessNuxj]= DerivativesNuxj(nux(:,j), x, hx, x_mj, Q, j, alpha, sum_rjsieqj05, r_j05, Anux_, Bnux_);
         HessNuxj = Negadefinize(HessNuxj);
         RWPrec = -HessNuxj./rwVarAdj;%RWPrec = diag((Bnux_.^2)./Anux_);%experiemnt
         RWVar = inv(RWPrec);
         nuxj_p = mvnrnd(nux(:,j),RWVar)'; 
         if all(nuxj_p > 0)
            Hjdiag = nuxj_p.*hx;
            Hjx_mj = bsxfun(@times, x_mj, Hjdiag);
            Q(:,j) = -0.5*sum(x_mj.*Hjx_mj,1)';
            [aexpQnorm_p, sumlogsumkaexpQ_p] = Qnormsumlogsum(Q,alpha);
            HessNuxj = - sum(bsxfun(@times, xxtvec(r_j05'), reshape(aexpQnorm_p(:,j) - aexpQnorm_p(:,j).^2, 1,1,n)),3) ...
                    - diag((Anux_- 1)./(nuxj_p.^2));
            HessNuxj = Negadefinize(HessNuxj);
            RWPropPrec = -HessNuxj./rwVarAdj;
            AccProb = exp(  (sum_rjsieqj05+Bnux_)'*(nux(:,j) - nuxj_p) ...
                      + (Anux_- 1)'* (log(nuxj_p)-log(nux(:,j))) ...        
                      - sumlogsumkaexpQ_p + sumlogsumkaexpQ ...
                      -lnnormpdf(nuxj_p,nux(:,j),RWPrec) + lnnormpdf(nux(:,j),nuxj_p,RWPropPrec));
            if rand < AccProb 
                nux(:,j) = nuxj_p;
                nuxAccCount(j) = nuxAccCount(j) + 1;
                aexpQnorm = aexpQnorm_p;
                sumlogsumkaexpQ = sumlogsumkaexpQ_p;
            else
                Q(:,j) = oldQj;
            end
        end
    end        
end   
 
% end block for nux_j, j=1,m  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
  
    
    
%%  Block for hx, Newton method for proposal%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
q = -0.5*reshape(((((repmat(reshape(mu, dx*m, 1)',n,1) - repmat(x',1,m)).^2).*repmat(reshape(nux, dx*m, 1)',n,1)))',dx,m*n);% q(:,(i-1)*m+j) is -0.5*((x_i-mu_j).^2).*nux_j
sumqisi = sum(q(:, s+(0:1:n-1)'*m),2);
DerivHx = @(argx) DerivativesHx(argx, q, sumqisi, n, m, dx, x, mu, nux, alpha, Ahx_, Bhx_, []);
[NewtonStatusHx, hx_pm, NHhx] = NewtonMethod(hx, DerivHx, @NewtonStepPosRestr, NewtonTol, Nnewtiter);

if NewtonStatusHx == 0
    % For JDT, multiply the r.h.s. in the following line by 0.1;  otherwise proposal seems to narrow to capture posterior
    NHhx = (NHhx + NHhx')./2; %looks like rounding errors lead to failure of symmetry check inside choletsky decomposition function, so symmetrize
    prpVar = -inv(NHhx);
    hx_p = mvnrnd(hx_pm,prpVar)'; 
    if all(hx_p > 0)
        Qp = ComputeQ(n, m, dx, x, mu, nux, hx_p);
        [aexpQnorm_p, sumlogsumkaexpQ_p] = Qnormsumlogsum(Qp,alpha);
        AccProb = exp( sumqisi'*(hx_p - hx) + sumlogsumkaexpQ - sumlogsumkaexpQ_p...
                  + (Ahx_./2- 1)'* (log(hx_p)-log(hx)) - Bhx_'*(hx_p.^0.5-hx.^0.5)...        
                  -0.5*(hx_p-hx_pm)'*NHhx*(hx_p-hx_pm)...
                  +0.5*(hx-hx_pm)'*NHhx*(hx-hx_pm));
        if rand < AccProb
            hx = hx_p;
            sumlogsumkaexpQ = sumlogsumkaexpQ_p;
            aexpQnorm = aexpQnorm_p;
            Q = Qp;
            hxAccCount = hxAccCount + 1;
        end
    end
else
    nonconvcount = nonconvcount + 1;
    [~,HessHx]= DerivHx(hx);
    HessHx = Negadefinize(HessHx);
    RWPrec = -HessHx./rwVarAdj;%0.01*diag((Bhx_.^2)./Ahx_).^2;%
    RWVar = inv(RWPrec);
    [~,err] = cholcov(RWVar);
    if err ~= 0
        RWVar = posidefinize(RWVar);
        RWPrec = inv(RWVar);
    end

    hx_p = mvnrnd(hx,RWVar)'; 
    if all(hx_p > 0)
        Qp = ComputeQ(n, m, dx, x, mu, nux, hx_p);
        [aexpQnorm_p, sumlogsumkaexpQ_p] = Qnormsumlogsum(Qp,alpha); 
        [~, HessHx] = DerivativesHx(hx_p, q, sumqisi, n, m, dx, x, mu, nux, alpha, Ahx_, Bhx_, aexpQnorm_p);
        HessHx = Negadefinize(HessHx);
        RWPropPrec = -HessHx./rwVarAdj;%RWPrec;%
        AccProb = exp( sumqisi'*(hx_p - hx) + sumlogsumkaexpQ - sumlogsumkaexpQ_p...
                  + (Ahx_./2- 1)'* (log(hx_p)-log(hx)) - Bhx_'*(hx_p.^0.5-hx.^0.5)...        
                   -lnnormpdf(hx_p,hx,RWPrec) + lnnormpdf(hx,hx_p,RWPropPrec));
        %                       -log(mvnpdf(hx_p,hx,inv(RWPrec))) + log(mvnpdf(hx,hx_p,inv(RWPropPrec))));
        if rand < AccProb
            hx = hx_p;
            sumlogsumkaexpQ = sumlogsumkaexpQ_p;
            aexpQnorm = aexpQnorm_p;
            Q = Qp;
            hxAccCount = hxAccCount + 1;
        end
    end
end
% End block for hx


  
