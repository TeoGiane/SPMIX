function plotdgpcpdf(fgnum, ygrid, xgrid, dgppdfeval)

nClmns = 1;
xgridlen = length(xgrid(1,:));
ypdf = reshape(repmat(ygrid, length(xgrid(1,:)), 1),1, length(ygrid)*length(xgrid(1,:)));
xpdf = repmat(xgrid, 1, length(ygrid));

condpdftrue = dgppdfeval(ypdf, xpdf);
figure(fgnum);

for xind = 1:xgridlen
    subplot(ceil(xgridlen/nClmns),nClmns,xind);
    plot(ygrid, condpdftrue(xind+xgridlen*(0:length(ygrid)-1)), 'LineStyle', '-', 'LineWidth', 2);
    hold on;
end
