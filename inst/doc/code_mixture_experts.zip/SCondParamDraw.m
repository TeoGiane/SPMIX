%mixreg model: Prior draw of allocation vars s conditional on parameters
function [s, mult_draw] = SCondParamDraw(expQ, alpha)
% Q=-0.5*reshape(sum(reshape((((repmat(reshape(mu, dx*m, 1)',n,1) - repmat(x',1,m)).*...
%    repmat(reshape(bsxfun(@times, sigmax, sx), dx*m, 1)',n,1)).^2)',dx,m*n)),m,n)';
% Q = exp(bsxfun(@minus, Q, max(Q,[],2))); % exp(Q - repmat(max(Q,[],2), 1, m)); %avoiding numerical over/under flow
Q1 = bsxfun(@times, expQ, alpha);
Q1 = bsxfun(@rdivide, Q1, sum(Q1,2)); 
mult_draw = mnrnd(1,Q1)';
[s, col] = find(mult_draw);
