% runs joint distribution tests for MCMC algorithm in "Optimal auxiliary priors and reversible jump proposals ..., by Andriy Norets (2016) 

clear; close all;
jdt_flag = 1;
Nsim = 20000;% # of MCMC iterations per simulator run
progress_step = 1000;
burnin = Nsim*0.1;


%initialize random var generator
rng(1235472);

n = 5; % sample size
dx = 2; % dim of x_i

%initalization for joint dist tests
% Prior hyperparameters
b_ = -ones(dx+1,1);
Hb_ = 10*diag(ones(1,dx+1));
Hb_b_ = Hb_*b_;
invHb_ = inv(Hb_);
mu_ = zeros(dx,1);
Hmu_ = 10*diag(ones(1,dx));
Hmu_mu_= Hmu_*mu_;
invHmu_ = inv(Hmu_);
A_ = 20;
Am_ = 1;
Amlogp_ = 0.5;%0.5;
Ahy_ = 10;
Bhy_ = 10;
Anuy_ = 20;%*ones(1,m);
Bnuy_ = 20;%*ones(1,m);
Ahx_ = 45*ones(dx, 1);
Bhx_ = 15*ones(dx, 1);
Anux_ = 25*ones(dx,1);
Bnux_ = 25*ones(dx,1);

%Initialize data
x = 1*(-1+2.*rand(dx,n)); x1 = [ones(1,n); x]; 
m0 = 3; % DGP # of mixture components
% DGP params = prior draw
[b0, mu0, alphaunn0, hy0, hx0, nuy0, nux0] = PriorDraw(m0, b_, invHb_, mu_, invHmu_, A_, Ahy_, Bhy_, Ahx_, Bhx_, Anuy_, Bnuy_, Anux_, Bnux_);
[y, s0, mult_draw0, N0]=DrawYScondParams(x,x1,b0, mu0, alphaunn0, hy0, hx0, nuy0, nux0);
dgpcpdfeval = @(ypdf,xpdf) pdfycondxparam(ypdf, xpdf, [ones(1,length(xpdf(1,:)));xpdf], b0, mu0, alphaunn0, hy0, hx0, nuy0, nux0, m0);






[sim_b, sim_mu, sim_alphaunn, sim_hy, sim_hx, sim_nuy, sim_nux, sim_m] ...
         = post_simulator4(y, x, x1,...
                         b0, mu0, alphaunn0, hy0, hx0, nuy0, nux0, m0, ...
                         b_, Hb_, mu_, Hmu_, A_, Ahy_, Bhy_, Ahx_, Bhx_, Anuy_, Bnuy_, Anux_, Bnux_, Am_, Amlogp_,...
                         Nsim, jdt_flag, progress_step);
             
                     
%  [sim_b, sim_mu, sim_alphaunn, sim_hy, sim_hx, sim_nuy, sim_nux, sim_m, currlogLikelihood, propPlogLikelihood] ...
%          = post_simulator3(y, x, x1,...
%                          b_, Hb_, mu_, Hmu_, A_, Ahy_, Bhy_, Ahx_, Bhx_, Anuy_, Bnuy_, Anux_, Bnux_, Am_, Amlogp_,...
%                          Nsim, jdt_flag, progress_step) ;                   
                     
                     
%%%%%%%%%%  plot priors and posteriors for parameters, uncomment for jdt                  
plot_test_postsimout; 
%%%%%%%%%

save('jdtest_1_13_17.mat');

% %Plot figures for paper %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % Defaults for this blog post
% width = 3;     % Width in inches
% height = 3;    % Height in inches
% alw = 0.75;    % AxesLineWidth
% fsz = 11;      % Fontsize
% lw = 1.5;      % LineWidth
% msz = 10;       % MarkerSize
% 
% close all;
% 
% % The properties we've been using in the figures
% set(0,'defaultLineLineWidth',lw);   % set the default line width to lw
% set(0,'defaultLineMarkerSize',msz); % set the default line marker size to msz
% set(0,'defaultLineLineWidth',lw);   % set the default line width to lw
% set(0,'defaultLineMarkerSize',msz); % set the default line marker size to msz
% 
% % Set the default Size for display
% defpos = get(0,'defaultFigurePosition');
% set(0,'defaultFigurePosition', [defpos(1) defpos(2) width*100, height*100]);
% 
% % Set the defaults for saving/printing to a file
% set(0,'defaultFigureInvertHardcopy','on'); % This is the default anyway
% set(0,'defaultFigurePaperUnits','inches'); % This is the default anyway
% defsize = get(gcf, 'PaperSize');
% left = (defsize(1)- width)/2;
% bottom = (defsize(2)- height)/2;
% defsize = [left, bottom, width, height];
% set(0, 'defaultFigurePaperPosition', defsize);
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% figure(40)
% %subplot(1,2,1);
% scatter(1:length(sim_m), sim_m, '.', 'MarkerEdgeColor',[0 0 0]);
% xlabel('iteration'); ylabel('m');
% hold on;
% 
% figure(41)
% scatter(1:length(probm),probm,  's', 'MarkerEdgeColor',[0 0 0]);%,'LineWidth', 5)
% hold on;
% scatter(1:length(freqm), freqm, '.', 'MarkerEdgeColor',[0 0 0]);%, 'LineWidth', 5)
% xlim([0.5 7.5])
% xlabel('m'); ylabel('pmf')


