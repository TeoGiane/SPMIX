% Get mean and variance for proposal by Newton method
% nstatus values: 
    % 0 - Newton converged
    % 1 - Nan somewhere
    % 2 - tolerance has not been reached after MaxIter Newton iterations


function [nstatus, x, H] = NewtonMethod(x0, Derivatives, NewtonStep, tolerance, MaxIter)

x = x0;
nstatus = 2; %initial status
H = []; return;
for newtiter = 1:MaxIter
    [J, H] = Derivatives(x);
    if any(isnan(H))
        nstatus = 1;
        break; 
    end
 %   if min(eig(-H))<0 % 
        H = Negadefinize(H);
 %   end
    v = H\J;
    if sum(abs(v)) < tolerance 
       nstatus = 0;
       break; 
    end
    x = x - NewtonStep(x,v)*v;
end


