% Author: andriy_norets@brown.edu
% The code can be used to replicate estimation results in Section 7.5 in the following paper:
%   Norets (2019), "Optimal auxiliary priors and reversible jump proposals
%   for a class of variable dimension models", 
% The script compares predictive performance of nonparametric Bayes conditional density estimator with several alternatives:
% (a) When FlagRunNPkernelEst = 1 below, a comparison with kernel estimate from np R package is performed; it requires 
%           installing R and R package np,
%           setting currPath to current Matlab folder in enclosed npest.r,
%           setting paths to R so that "system('R CMD BATCH npest.r');" successfully runs from Matlab
% (b) normal linear regression
% (c) normal 2nd order polynomial regression
% The comparison is done on real or artificial data as follows: 
%       I:   randomly select a subset of data for estimation 
%       II:  run posterior simulator on it
%       III: calculate log scores (log predicitve density on data not used in estimation)
%       - repeat I-III in a loop "mc_len" times and report average log scores

clear; close all;

FlagRunNPkernelEst = 0; %see comments above in (a) about setting this to 1

if isunix
    % Code to run on Linux plaform
    path(path,'/home/anorets/MC01')
elseif ispc
    % Code to run on Windows platform
else
    disp('Cannot recognize platform')
end

%initialization for estimation from art data or joint distribution tests
jdt_flag = 0;% set to 1 for joint distribution tests for correctness of MCMC implementation, at this point should not be used in this script, use jdtest.m to perform the tests
Nsim = 10000;% # of MCMC iterations, set to 100000 to get results in the paper
progress_step = 1000;% Current run time and some current MCMC draws and acceptance rates reported every progress_step MCMC iterations
burnin = Nsim*0.1; % first 10% of MCMC draws are discarded
mc_len = 1; % # of times estimation is performed on a randomly selected subset of data
LogPredDensBayes = zeros(1,mc_len);
LogPredDensNP = zeros(1,mc_len);
LogPredDensOLS = zeros(1,mc_len);
LogPredDensOLS2 = zeros(1,mc_len);

% Simulate data
% rng(135461);
% all_n = 2000; % total sample size
% n = floor(all_n*0.9);% size of the subsample used in estimation
% pred_n = all_n - n;% size of subsample used for prediction
% dx = 2;%dimension of x
% % Simulate data from a nonlinear additevely separable model with conditionally heteroskedastic gamma*normal errors
% all_x = normrnd(0, 1,dx,all_n);
% x_pow = repmat((1:dx)',1,all_n);
% all_y = sum(all_x.^x_pow);
% all_y = all_y +exp(all_y./max(abs(all_y))).*normrnd(0, 1,1,all_n).*gamrnd(1,1,1,all_n);

%Load real data: birthweight
% datFromFile = dlmread('birthdat_cell.txt'); %datFromFile = dlmread('C:\Users\Andriy_Norets\Dropbox\work\projects\mixtures\birthdatstata\birthdat_cell.txt');
% all_n = length(datFromFile(:,1));
% n = floor(all_n*0.1);% size of the subsample used in estimation
% pred_n = all_n - n;% size of subsample used for prediction
% dx = 3;%dimension of x
% all_y = datFromFile(:,1)';
% all_x = datFromFile(:,2:2+dx-1)';
% %all_x = datFromFile(:,[2,4])';

%Load real data: engel curve, food budget share regressed on total expenditure
datFromFile = csvread('bn-data.csv',1,0);
all_n = length(datFromFile(:,1));
n = floor(all_n*0.5);% size of the subsample used in estimation
pred_n = all_n - n;% size of subsample used for prediction
dx = 1;%dimension of x
all_y = datFromFile(:,1)';
all_x = datFromFile(:,2:2+dx-1)';
%all_x = datFromFile(:,[2,4])';




% plot data
%for j = 1:dx, figure(1000+j);  scatter(all_x(j,:),all_y); end


for mc_ind = 1:mc_len
%initialize random var generator
rng(135462+mc_ind);%rng(235462);

%Randomly select data subset for estimation 
rand_indcs = randperm(all_n);
y = all_y(1,rand_indcs(1:n));
x = all_x(:,rand_indcs(1:n));
%plot estimation data
%for j = 1:dx, figure(2000+j); scatter(x(j,:),y); end


% Rescale data - it is a sort of empirical Bayes
xm = mean(x,2);
xvar = cov(x');
chol_xvarinv = chol(inv(xvar));
ym = mean(y);
sdy = std(y);
x = bsxfun(@minus, x, xm);
x = chol_xvarinv*x;
y = (y - ym)./sdy;
x1 = [ones(1,n); x];
%Rescale data used for evaluaing predictive performance
pred_y = all_y(1,rand_indcs(n+1:end));
pred_x = all_x(:,rand_indcs(n+1:end));
pred_x = bsxfun(@minus, pred_x, xm);
pred_x = chol_xvarinv*pred_x;
pred_y = (pred_y - ym)./sdy;

%Save data in text file for R package np
dataforR=[x' y'];
if FlagRunNPkernelEst
    save 'EstDataForR.txt' dataforR -ascii
end

%Data dependent prior/empirical bayes for regression coeffs
%[olsb, olserrvar, b_, Hb_, mu_, Hmu_, A_, Ahy_, Bhy_, Ahx_, Bhx_, Anuy_, Bnuy_, Anux_, Bnux_, Am_, Amlogp_] = EBayesDefaultPriorParamsOrig(y,x,x1);

[xmean, xvar, olsb, olserrvar, b_, Hb_, mu_, Hmu_, A_, Ahy_, Bhy_, Ahx_, Bhx_, Anuy_, Bnuy_, Anux_, Bnux_, Am_, Amlogp_] = EBayesDefaultPriorParamsOrig(y,x,x1);

%prior_pred_analysis; % uncomment to check how prior for params looks like and prior predictive density look like

rng(723546201);

             
                     
%Initialize parameters
m0 = 1;
mu0 = xmean;
b0 = olsb; 
hy0 = 1./sqrt(olserrvar);%gamrnd(Ahy_, 1./Bhy_);%hy = 1;
nuy0 = 1./(olserrvar*hy0);
hx0 = 1./sqrt(diag(xvar));%ones(dx,1);
nux0 = 1./(diag(xvar).*hx0);
alphaunn0 = gamrnd(ones(1,m0).*A_./m0,1); alpha0=alphaunn0/sum(alphaunn0); 


% Call posterior simulator %%%%%%%%%%%%%%%%%%%%%%%%%% 

[sim_b, sim_mu, sim_alphaunn, sim_hy, sim_hx, sim_nuy, sim_nux, sim_m, currlogLikelihood, propPlogLikelihood] ...
         = post_simulator4(y, x, x1,...
                            b0, mu0, alphaunn0, hy0, hx0, nuy0, nux0, m0,...
                            b_, Hb_, mu_, Hmu_, A_, Ahy_, Bhy_, Ahx_, Bhx_, Anuy_, Bnuy_, Anux_, Bnux_, Am_, Amlogp_,...
                            Nsim, jdt_flag, progress_step);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                     
                     
                     
                     
 
% % % %plot post mean of cond.pdf and its q and 1-q quantiles
miny = min(y);
maxy = max(y);
ygridPlot = miny:(maxy-miny)/100:maxy;
xgrid1d = min(x):(max(x)-min(x))/10:max(x);%[0.25, 0.75];
xgridRMSE = GridNDLin(xgrid1d, dx);
xgridPlot = [xgrid1d; xgrid1d(ceil(length(xgrid1d)/2))*ones(dx-1,length(xgrid1d))];
q = 0.0001;
%plotpostpdfdraws(100, ygridPlot, xgridPlot, sim_b, sim_mu, sim_alphaunn, sim_hy, sim_hx, sim_nuy, sim_nux, sim_m, Nsim, 10, q, ym, sdy, xm, chol_xvarinv);
% Plot kernel estimates from R package np
% if FlagRunNPkernelEst
%     plotnpcpdf(101, ygridPlot, xgridPlot, 1);
% end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                  
% compute LogPredDens for Bayes
LogPredDensBayes(mc_ind) = sum(log(mean(postdraws_condpdf(pred_y, pred_x, [ones(1,length(pred_x(1,:)));pred_x],...
                     sim_b(:,:,burnin:end), sim_mu(:,:,burnin:end), sim_alphaunn(:,burnin:end), sim_hy(:,burnin:end), sim_hx(:,burnin:end), sim_nuy(:,burnin:end), sim_nux(:,:,burnin:end), sim_m(:,burnin:end),...   
                         Nsim-burnin+1, 1),2)));
                     
%likelihood cross-validated kernel estimator from R package np
if FlagRunNPkernelEst
    LogPredDensNP(mc_ind) = CompLogPredDensNP(pred_y, pred_x, 1);
end

% Normal linear regression 
LogPredDensOLS(mc_ind) = 0.5*pred_n*(-log(olserrvar) -log(2*pi)) - 0.5*sum((pred_y - olsb'*[ones(1, pred_n); pred_x]).^2)./olserrvar;% CompLogPredDensNP(pred_y, pred_x, 1);

% Normal regression with second order polynomial
x1nln = [ones(1, n); x]; % x.^2; x(1,:).*x(2,:); x(1,:).*x(3,:); x(2,:).*x(3,:)];
x1prednln = [ones(1, pred_n); pred_x];% pred_x.^2; pred_x(1,:).*pred_x(2,:); pred_x(1,:).*pred_x(3,:); pred_x(2,:).*pred_x(3,:)];

for i_ind = 1:dx
    for j_ind = i_ind:dx
        x1nln =  [x1nln; x(i_ind,:).*x(j_ind,:)];
        x1prednln =  [x1prednln; pred_x(i_ind,:).*pred_x(j_ind,:)];
    end
end

olsbnln=(x1nln*x1nln')\(x1nln*y');
olserrvarnln = mean((y - olsbnln'*x1nln).^2);
LogPredDensOLS2(mc_ind) = 0.5*pred_n*(-log(olserrvarnln) -log(2*pi)) - 0.5*sum((pred_y - olsbnln'*x1prednln).^2)./olserrvarnln;% CompLogPredDensNP(pred_y, pred_x, 1);

%tablogscore = [mean(LogPredDensBayes(1:mc_ind)), mean(LogPredDensNP(1:mc_ind)), mean(LogPredDensBayes(1:mc_ind)-LogPredDensNP(1:mc_ind)), mean(LogPredDensBayes(1:mc_ind)<LogPredDensNP(1:mc_ind)), sqrt(length(LogPredDensBayes(1:mc_ind)))*mean(LogPredDensBayes(1:mc_ind)-LogPredDensNP(1:mc_ind))./std(LogPredDensBayes(1:mc_ind)-LogPredDensNP(1:mc_ind))]
AvgPredLogScoreBayesKernelOlsOls2 = [mean(LogPredDensBayes(1:mc_ind)), mean(LogPredDensNP(1:mc_ind)), mean(LogPredDensOLS2(1:mc_ind)), mean(LogPredDensOLS(1:mc_ind))]
end



save('est_9_10_19_EngelData100Krun.mat');
% 
plotpostpdfdraws(100, ygridPlot, xgridPlot, sim_b, sim_mu, sim_alphaunn, sim_hy, sim_hx, sim_nuy, sim_nux, sim_m, Nsim, 10, q, ym, sdy, xm, chol_xvarinv);
scatter3(all_x,all_y,zeros(size(all_x)),'.');
ylabel('food share');
xlabel('log(total expenditure)');

condmeandraws = postdraws_condmean(xgridPlot, [ones(1,length(xgridPlot(1,:)));xgridPlot],...
                         sim_b, sim_mu, sim_alphaunn, sim_hy, sim_hx, sim_nuy, sim_nux, sim_m, ...
                         Nsim, 10);

condmean_mean = ym+mean(condmeandraws,2).*sdy;
for xind = 1:length(xgridPlot(1,:))
    x4plot(:,xind) = xm + inv(chol_xvarinv)*xgridPlot(:,xind);
end
line(x4plot,condmean_mean,zeros(size(xgridPlot)), 'LineWidth', 2, 'color', 'k', 'LineStyle', '--');

% figure(8); xlabel('iteration'); ylabel('m');
% for traceplots and pmfs run code from plot_test_postsimout.m and jdtest
% figures 40 and 41
