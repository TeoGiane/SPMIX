function [helle, mae] = hellingermaepostcpdf(dgppdfeval, ygrid, xgrid,...
                          sim_b, sim_mu, sim_alphaunn, sim_hy, sim_hx, sim_nuy, sim_nux, sim_m, ...
                         Nsim, thin_step)

xgridlen = length(xgrid(1,:));
ypdf = reshape(repmat(ygrid, length(xgrid(1,:)), 1),1, length(ygrid)*length(xgrid(1,:)));
xpdf = repmat(xgrid, 1, length(ygrid));

condpdfdraws = postdraws_condpdf(ypdf, xpdf, [ones(1,length(xpdf(1,:)));xpdf],...
                         sim_b, sim_mu, sim_alphaunn, sim_hy, sim_hx, sim_nuy, sim_nux, sim_m, ...
                         Nsim, thin_step);
meancpdfd = mean(condpdfdraws,2);                    
condpdftrue = dgppdfeval(ypdf, xpdf);
abserror = abs(condpdftrue - meancpdfd');
errorsqrt2 = (sqrt(condpdftrue) - sqrt(meancpdfd')).^2;
helle = sum(errorsqrt2)./length(errorsqrt2); %hellinger divided by grid length on y
mae = sum(abserror)./length(abserror);

