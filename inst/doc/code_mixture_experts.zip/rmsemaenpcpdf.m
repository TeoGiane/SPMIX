function [rmse, mae] = rmsemaenpcpdf(dgppdfeval, ygrid, xgrid, flagRecalc)

xgridlen = length(xgrid(1,:));
ypdf = reshape(repmat(ygrid, length(xgrid(1,:)), 1),1, length(ygrid)*length(xgrid(1,:)));
xpdf = repmat(xgrid, 1, length(ygrid));

if flagRecalc
    dataforRpred=[xpdf' ypdf'];
    save 'PredDataForR.txt' dataforRpred -ascii;
%    path(path,'C:/Program Files/R/R-3.2.2/bin');
    
    system('R CMD BATCH npest.r'); 
end

npcpdfvals = importdata('cdensPredFromR.txt');
           
condpdftrue = dgppdfeval(ypdf, xpdf);
abserror = abs(condpdftrue - npcpdfvals');
rmse = sqrt(sum(abserror.^2)./length(abserror));
mae = sum(abserror)./length(abserror);

