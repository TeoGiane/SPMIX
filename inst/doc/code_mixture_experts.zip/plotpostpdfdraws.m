function plotpostpdfdraws(fgnum, ygrid, xgrid,...
                          sim_b, sim_mu, sim_alphaunn, sim_hy, sim_hx, sim_nuy, sim_nux, sim_m, ...
                         Nsim, thin_step, q, ym, sdy, xm, chol_xvarinv)
nClmns = 1;
lnWidth = 2;
xgridlen = length(xgrid(1,:));
ypdf = reshape(repmat(ygrid, length(xgrid(1,:)), 1),1, length(ygrid)*length(xgrid(1,:)));
xpdf = repmat(xgrid, 1, length(ygrid));

condpdfdraws = postdraws_condpdf(ypdf, xpdf, [ones(1,length(xpdf(1,:)));xpdf],...
                         sim_b, sim_mu, sim_alphaunn, sim_hy, sim_hx, sim_nuy, sim_nux, sim_m, ...
                         Nsim, thin_step);
% condpdftrue = pdfycondxparam(ypdf, xpdf, [ones(1,length(xpdf(1,:)));xpdf], b0, mu0, alpha0, hy0, hx0, nuy0, nux0, m0);
figure(fgnum);
meancpdfd = mean(condpdfdraws,2);
sortcpdfd = sort(condpdfdraws,2);
qlind = max(round(length(condpdfdraws(1,:))*q),1);
qrind = round(length(condpdfdraws(1,:))*(1-q));
qlcpdf = sortcpdfd(:, qlind);
qrcpdf = sortcpdfd(:, qrind);

%Plot conditional densities for several values of x
% for xind = 1:xgridlen
%     subplot(ceil(xgridlen/nClmns),nClmns,xind);
%     plot(ygrid, meancpdfd(xind+xgridlen*(0:length(ygrid)-1)), 'LineStyle', '-.', 'LineWidth', lnWidth);
%     hold on;
%     plot(ygrid, qlcpdf(xind+xgridlen*(0:length(ygrid)-1)), 'LineStyle', '--', 'LineWidth', lnWidth);
%     hold on;
%     plot(ygrid, qrcpdf(xind+xgridlen*(0:length(ygrid)-1)), 'LineStyle', '--', 'LineWidth', lnWidth);
%     hold on;
% %    plot(ygrid, condpdftrue(xind+xgridlen*(0:length(ygrid)-1)), 'LineStyle', '-');
% %    hold on;
% end

%Plot in 3d assuming grid on x is a grid on coordinate 1 and the other x coordinates are either constant or dx=1
figure(fgnum);
for xind = 1:xgridlen
    x4plot = xm + inv(chol_xvarinv)*xgrid(:,xind);
    plot3(repmat(x4plot(1),size(ygrid)), ym+ygrid.*sdy, meancpdfd(xind+xgridlen*(0:length(ygrid)-1)), 'LineWidth', lnWidth);
    hold on;
end
%scatter3(all_x,all_y,zeros(size(all_x)),'.'); % execute this line after real_data estimation script finished to add raw data to conditional density plots
%ylabel('food share'); xlabel('log(total expenditure');
