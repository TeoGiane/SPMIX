%mixreg model: Compute Q with Q_{ij}=-0.5(x_i-mu_j)'Sigma_j (x_i-mu_j)
% for each i normalized along j so that max_j Q_{ij} = 1
function [mump1_pm, d2logPdmump12, bmp1_pm, d2logPdbmp12, nuxmp1_pm, d2logPdnuxmp12, nuymp1_pm, d2logPdnuymp12, aunnmp1_pm, d2logPdaunnmp12] ...
              = RetrPriorParams(n, m, dx, y, x, x1, hy, hx, b, mu, nux, nuy, alphaunn, bmp1_pm0, mump1_pm0, nuxmp1_pm0, nuymp1_pm0, aunnmp1_pm0, b_, Hb_, mu_, Hmu_, A_, Anuy_, Bnuy_, Anux_, Bnux_)

Nnewtiter = 1000;      
NewtonTol = 10^-6; % for tolerance less than 10^-14 there are convergence problems

bmp1_pm = bmp1_pm0;
mump1_pm = mump1_pm0;
nuxmp1_pm = nuxmp1_pm0;
nuymp1_pm = nuymp1_pm0;
aunnmp1_pm = aunnmp1_pm0;

bmp1 = [b, bmp1_pm];%[b, mvnrnd(b_',invHb_, 1)'];
mump1 = [mu, mump1_pm];%[mu, mvnrnd(mu_',invHmu_, 1)'];    
nuymp1 = [nuy, nuymp1_pm];%[nuy, gamrnd(Anuy_(:,1), 1./Bnuy_(:,1))];
nuxmp1 = [nux, nuxmp1_pm];%[nux, gamrnd(Anux_(:,1), 1./Bnux_(:,1))];   
alphaunnmp1 = [alphaunn,aunnmp1_pm]; % alphaunn(1:m) here is a 
alphamp1 = alphaunnmp1./sum(alphaunnmp1); 
       
          


    
%    currLogLklhd = ComputeLogLklhd(n, m, dx, y, x, b, mu, nux, hx, x1, nuy, hy, alpha);
    

    % the following commented code is for plotting likelihood at debugging
    % stage to make sure there is a unique max and Newton method works, etc
%     ComputeLogLklhdMump1 = @(z) ComputeLogLklhd(n, m+1, dx, y, x, bmp1, [mu,z], nuxmp1, hx, x1, nuymp1, hy, alphamp1);
%     ComputeLogLklhdbmp1 = @(z) ComputeLogLklhd(n, m+1, dx, y, x, [b,z], mump1, nuxmp1, hx, x1, nuymp1, hy, alphamp1);
%     ComputeLogLklhdnuxmp1 = @(z) ComputeLogLklhd(n, m+1, dx, y, x, bmp1, mump1, [nux,z], hx, x1, nuymp1, hy, alphamp1);
%     ComputeLogLklhdnuymp1 = @(z) ComputeLogLklhd(n, m+1, dx, y, x, bmp1, mump1, nuxmp1, hx, x1, [nuy,z], hy, alphamp1);

%     grdRng = 10;
%     grdSz = 100;
%     lklhdsurf = zeros(grdSz,grdSz);
%     for ii1=1:grdSz
%         for jj2 = 1:grdSz
%             z = - 0.5*grdRng +  [ii1*grdRng./grdSz;jj2*grdRng./grdSz];
%             lklhdsurf(ii1,jj2) = ComputeLogLklhdmp1(z) - 0.5*(z-mu_)'*Hmu_*(z-mu_);
%         end
%     end
%      figure(38)
%     surf(lklhdsurf)

% grdRng = 2;
% grdSz = 10000;
% lklhdy = zeros(grdSz);
% z  = zeros(grdSz);
% for ii1=1:grdSz
% 
%         z(ii1) = - 0.5*grdRng +  ii1*grdRng./grdSz;
%         lklhdy(ii1) =  - 0.5*(z(ii1)-mu_)'*Hmu_*(z(ii1)-mu_) + ComputeLogLklhdMump1(z(ii1));
% end
% figure(56)
% plot(z,lklhdy)

%     grdRng = 10;
%     grdSz = 100;
%     lklhdsurf = zeros(grdSz,grdSz);
%     z = zeros(dx+1,1);
%     for ii1=1:grdSz
%         for jj2 = 1:grdSz
%             z(dx:dx+1,1) = - 0.5*grdRng +  [ii1*grdRng./grdSz;jj2*grdRng./grdSz];
%             lklhdsurf(ii1,jj2) = ComputeLogLklhdbmp1(z);% - 0.5*(z-b_)'*Hb_*(z-b_);
%         end
%     end
%      figure(42)
%     surf(lklhdsurf)

%     grdRng = 10;
%     grdSz = 100;
%     lklhdsurf = zeros(grdSz,grdSz);
%     for ii1=1:grdSz
%         for jj2 = 1:grdSz
%             z = [ii1*grdRng./grdSz;jj2*grdRng./grdSz];
%             lklhdsurf(ii1,jj2) = ComputeLogLklhdnuxmp1(z)+(Anux_- 1)'*log(z) - Bnux_'*z;
%             %lklhdsurf(ii1,jj2) = (Anux_- 1)'*log(z) - Bnux_'*z;
%         end
%     end
%      figure(45)
%     surf(lklhdsurf)
% plot((Anux_(1)- 1)*log([1:100]*0.01) - Bnux_(1)*[1:100]*0.01);
% 

% 
%     grdRng = 2;
%     grdSz = 100;
%     lklhdy = zeros(grdSz);
%     for ii1=1:grdSz
%  
%             z(ii1) = ii1*grdRng./grdSz;
%             lklhdy(ii1) = ComputeLogLklhdnuymp1(z(ii1))+(Anuy_- 1)'*log(z(ii1)) - Bnuy_'*z(ii1);
%             %lklhdsurf(ii1,jj2) = (Anux_- 1)'*log(z) - Bnux_'*z;
% 
%     end
%      figure(45)
%     plot(z,lklhdy)

% ComputeLogLklhdaunnmp1 = @(z) ComputeLogLklhd(n, m+1, dx, y, x, bmp1, mump1, nuxmp1, hx, x1, nuymp1, hy, [alphaunn,z])
% grdRng = 20;
% grdSz = 1000;
% lklhdy = zeros(grdSz);
% for ii1=1:grdSz
% 
%         z(ii1) = ii1*grdRng./grdSz;
%         lklhdy(ii1) = ComputeLogLklhdaunnmp1(z(ii1))+(A_./(m+1)- 1)*log(z(ii1)) - z(ii1);
% end
% figure(55)
% plot(z,lklhdy)
     
    
for newtiter = 1:Nnewtiter

    %Newton stp for mump1
    mump1 = [mu,mump1_pm];
    Q = ComputeQ(n, m+1, dx, x, mump1, nuxmp1, hx);
    [aexpQnorm, sumlogsumkaexpQ] = Qnormsumlogsum(Q,alphamp1);       
    Eps = bsxfun(@minus, y', reshape(sum(reshape(bsxfun(@times, repmat(x1',1,m+1), reshape(bmp1,1,(m+1)*(dx+1)))', dx+1, (m+1)*n)),(m+1),n)'); 
    %meps2hdiv2 = -0.5*bsxfun(@times, Eps.^2, nuymp1.*hy);
    %Qynorm = bsxfun(@times, exp( bsxfun(@minus, meps2hdiv2, max(meps2hdiv2,[],2))), sqrt(nuymp1.*hy));
    %Qymp1DivLcomp = Qynorm(:,m+1)./sum(aexpQnorm.*Qynorm,2);

    QyQloganormmp1 = ComputeQyQloganormmp1(Eps, nuymp1, hy, Q, alphamp1);
    
    phil1c = QyQloganormmp1-aexpQnorm(:,m+1);
    Hmp1x_mump1 = bsxfun(@times,bsxfun(@minus,x,mump1(:,m+1)), nuxmp1(:,m+1).*hx);

    dlogPdmump1 = Hmp1x_mump1 * phil1c + Hmu_*(mu_-mump1(:,m+1));

    Hmp1 = diag(nuxmp1(:,m+1).*hx);
    d2logPdmump12 = -sum(phil1c)*Hmp1 ...
    + sum(bsxfun(@times, xxtvec(Hmp1x_mump1'), reshape(phil1c.*(1-aexpQnorm(:,m+1) - QyQloganormmp1), 1,1,n)),3) ... 
    - Hmu_;

    if any(isnan(d2logPdmump12(:)))  || any(isinf(d2logPdmump12(:)))
        [mump1_pm, d2logPdmump12, bmp1_pm, d2logPdbmp12, nuxmp1_pm, d2logPdnuxmp12, nuymp1_pm, d2logPdnuymp12, aunnmp1_pm, d2logPdaunnmp12] ...
         = RetrPriorParamsSim(n, m, dx, y, x, x1, hy, hx, b, mu, nux, nuy, alphaunn, bmp1_pm0, mump1_pm0, nuxmp1_pm0, nuymp1_pm0, aunnmp1_pm0, b_, Hb_, mu_, Hmu_, A_, Anuy_, Bnuy_, Anux_, Bnux_);
        break;
    end;
    
    d2logPdmump12 = Negadefinize(d2logPdmump12);
    



    stp = 0.9;
    vmu = d2logPdmump12\dlogPdmump1;
    mump1_pm = mump1_pm - stp*vmu;
    mump1 = [mu,mump1_pm];
    Q = ComputeQ(n, m+1, dx, x, mump1, nuxmp1, hx);
    %aexpQ = bsxfun(@times, exp(Q), alphamp1);
    %aexpQnorm = bsxfun(@rdivide, aexpQ, sum(aexpQ,2));
    [aexpQnorm, sumlogsumkaexpQ] = Qnormsumlogsum(Q,alphamp1);

    %Lcomp = sum(aexpQnorm.*Qy,2);  
    %Qymp1DivLcomp = Qynorm(:,m+1)./sum(aexpQnorm.*Qynorm,2);
    QyQloganormmp1 = ComputeQyQloganormmp1(Eps, nuymp1, hy, Q, alphamp1);




    %Newton stp for nuxmp1
    kappa = -0.5* bsxfun(@times,bsxfun(@minus,x,mump1(:,m+1)).^2, hx);
    dlogPdnuxmp1 = kappa * (QyQloganormmp1 - aexpQnorm(:,m+1)) + (Anux_- 1)./nuxmp1(:,m+1) - Bnux_;
    d2logPdnuxmp12 = sum(bsxfun(@times, xxtvec(kappa'), reshape(...
        (QyQloganormmp1 - aexpQnorm(:,m+1)).*(1-aexpQnorm(:,m+1)-QyQloganormmp1), 1,1,n)),3) ... 
    - diag((Anux_- 1)./(nuxmp1(:,m+1).^2));
 

    if any(isnan(d2logPdnuxmp12(:))) || any(isinf(d2logPdnuxmp12(:)))
        [mump1_pm, d2logPdmump12, bmp1_pm, d2logPdbmp12, nuxmp1_pm, d2logPdnuxmp12, nuymp1_pm, d2logPdnuymp12, aunnmp1_pm, d2logPdaunnmp12] ...
         = RetrPriorParamsSim(n, m, dx, y, x, x1, hy, hx, b, mu, nux, nuy, alphaunn, bmp1_pm0, mump1_pm0, nuxmp1_pm0, nuymp1_pm0, aunnmp1_pm0, b_, Hb_, mu_, Hmu_, A_, Anuy_, Bnuy_, Anux_, Bnux_);
        break;
    end;

    d2logPdnuxmp12 = Negadefinize(d2logPdnuxmp12);
    vnux = d2logPdnuxmp12\dlogPdnuxmp1;
    
    stp = min([nuxmp1_pm(vnux>0)./vnux(vnux>0); 1])*0.9;
    if isempty(stp), stp = 0.9; end;

    nuxmp1_pm = nuxmp1_pm - stp*vnux;
    nuxmp1 = [nux,nuxmp1_pm];    

    Q = ComputeQ(n, m+1, dx, x, mump1, nuxmp1, hx);
    %aexpQ = bsxfun(@times, exp(Q), alphamp1);
    %aexpQnorm = bsxfun(@rdivide, aexpQ, sum(aexpQ,2));
    [aexpQnorm, sumlogsumkaexpQ] = Qnormsumlogsum(Q,alphamp1);
    %Lcomp = sum(aexpQnorm.*Qy,2);       
    %Qymp1DivLcomp = Qynorm(:,m+1)./sum(aexpQnorm.*Qynorm,2);
    QyQloganormmp1 = ComputeQyQloganormmp1(Eps, nuymp1, hy, Q, alphamp1);


    %Newton stp for b
    dlogPdbmp1 = (hy*nuymp1(m+1)).*(x1 * (QyQloganormmp1.*Eps(:,m+1))) + Hb_*(b_-bmp1(:,m+1));

    d2logPdbmp12 = -(hy*nuymp1(m+1)).*sum(bsxfun(@times, xxtvec(x1'), reshape(...
        QyQloganormmp1.*(1-(hy*nuymp1(m+1)).*(Eps(:,m+1).^2).*(1-QyQloganormmp1)), 1,1,n)),3) ... 
    - Hb_;

    if any(isnan(d2logPdbmp12(:))) || any(isinf(d2logPdbmp12(:)))
        [mump1_pm, d2logPdmump12, bmp1_pm, d2logPdbmp12, nuxmp1_pm, d2logPdnuxmp12, nuymp1_pm, d2logPdnuymp12, aunnmp1_pm, d2logPdaunnmp12] ...
         = RetrPriorParamsSim(n, m, dx, y, x, x1, hy, hx, b, mu, nux, nuy, alphaunn, bmp1_pm0, mump1_pm0, nuxmp1_pm0, nuymp1_pm0, aunnmp1_pm0, b_, Hb_, mu_, Hmu_, A_, Anuy_, Bnuy_, Anux_, Bnux_);
        break;
    end;

    d2logPdbmp12 = Negadefinize(d2logPdbmp12);
     

    vb = d2logPdbmp12\dlogPdbmp1;
    stp = 0.9;



%     if isnan(d2logPdmump12)%min(abs(eig(d2logPdmump12)))< NewtonTol
%         stopp = 1;
%     end

    bmp1_pm = bmp1_pm - stp*vb;
    bmp1 = [b,bmp1_pm];
    %Qy = reshape(sum(reshape(bsxfun(@times, repmat(x1',1,m+1), reshape(bmp1,1,(m+1)*(dx+1)))', dx+1, (m+1)*n)),(m+1),n)';
    Eps = bsxfun(@minus, y', reshape(sum(reshape(bsxfun(@times, repmat(x1',1,m+1), reshape(bmp1,1,(m+1)*(dx+1)))', dx+1, (m+1)*n)),(m+1),n)');      
    %meps2hdiv2 = -0.5*bsxfun(@times, Eps.^2, nuymp1.*hy);
    %Qynorm = bsxfun(@times, exp( bsxfun(@minus, meps2hdiv2, max(meps2hdiv2,[],2))), sqrt(nuymp1.*hy));
    %Qymp1DivLcomp = Qynorm(:,m+1)./sum(aexpQnorm.*Qynorm,2);
    QyQloganormmp1 = ComputeQyQloganormmp1(Eps, nuymp1, hy, Q, alphamp1);
    


    kappay = -0.5* (Eps(:,m+1).^2)*hy;
    dlogPdnuymp1 = sum((kappay+0.5./nuymp1(:,m+1)) .* QyQloganormmp1) + (Anuy_- 1)./nuymp1(:,m+1) - Bnuy_;
    d2logPdnuymp12 = sum(   QyQloganormmp1.*(  ((kappay+0.5./nuymp1(:,m+1)).^2).*(1-QyQloganormmp1) -0.5./ nuymp1(:,m+1).^2)) ... 
                     - diag((Anuy_- 1)./(nuymp1(:,m+1).^2));
                 
    if any(isnan(d2logPdnuymp12(:))) || any(isinf(d2logPdnuymp12(:)))
        [mump1_pm, d2logPdmump12, bmp1_pm, d2logPdbmp12, nuxmp1_pm, d2logPdnuxmp12, nuymp1_pm, d2logPdnuymp12, aunnmp1_pm, d2logPdaunnmp12] ...
         = RetrPriorParamsSim(n, m, dx, y, x, x1, hy, hx, b, mu, nux, nuy, alphaunn, bmp1_pm0, mump1_pm0, nuxmp1_pm0, nuymp1_pm0, aunnmp1_pm0, b_, Hb_, mu_, Hmu_, A_, Anuy_, Bnuy_, Anux_, Bnux_);
        break;
    end;

    d2logPdnuymp12 = Negadefinize(d2logPdnuymp12);           
                 
    vnuy = d2logPdnuymp12\dlogPdnuymp1;

    stp = min([nuymp1_pm(vnuy>0)./vnuy(vnuy>0); 1])*0.9;
    if isempty(stp), stp = 0.9; end;

    nuymp1_pm = nuymp1_pm - stp*vnuy;
    nuymp1 = [nuy,nuymp1_pm];    







%Newton stp for alphaunnmp1 (unnormalized alpha_mp1)

      %unnormalize alpha
     %Qy = bsxfun(@times, exp(-0.5*bsxfun(@times, Eps.^2, nuymp1.*hy)), sqrt(nuymp1.*hy));
    [aexpQnorm, sumlogsumkaexpQ] = Qnormsumlogsum(ComputeQ(n, m+1, dx, x, mump1, nuxmp1, hx),alphaunnmp1);  
    %meps2hdiv2 = -0.5*bsxfun(@times, Eps.^2, nuymp1.*hy);
    %Qynorm = bsxfun(@times, exp( bsxfun(@minus, meps2hdiv2, max(meps2hdiv2,[],2))), sqrt(nuymp1.*hy));
    %Qymp1DivLcomp = Qynorm(:,m+1)./sum(aexpQnorm.*Qynorm,2);
    QyQloganormmp1 = ComputeQyQloganormmp1(Eps, nuymp1, hy, Q, alphamp1);

    
    
    dlogPdaunnmp1 = sum((QyQloganormmp1 - aexpQnorm(:,m+1))./alphaunnmp1(m+1)) +  (A_./(m+1)-1)./alphaunnmp1(m+1) - 1;
    d2logPdaunnmp12 = sum(  (aexpQnorm(:,m+1).^2 - QyQloganormmp1.^2)./(alphaunnmp1(m+1).^2)) -  (A_./(m+1)-1)./(alphaunnmp1(m+1).^2);
 
    if any(isnan(d2logPdaunnmp12(:))) || any(isinf(d2logPdaunnmp12(:)))
        [mump1_pm, d2logPdmump12, bmp1_pm, d2logPdbmp12, nuxmp1_pm, d2logPdnuxmp12, nuymp1_pm, d2logPdnuymp12, aunnmp1_pm, d2logPdaunnmp12] ...
         = RetrPriorParamsSim(n, m, dx, y, x, x1, hy, hx, b, mu, nux, nuy, alphaunn, bmp1_pm0, mump1_pm0, nuxmp1_pm0, nuymp1_pm0, aunnmp1_pm0, b_, Hb_, mu_, Hmu_, A_, Anuy_, Bnuy_, Anux_, Bnux_);
        break;
    end;

    
    % switch to gradient descent when  d2logPdaunnmp12 > 0 
%     if d2logPdaunnmp12 > 0 
%        d2logPdaunnmp12 = -d2logPdaunnmp12; 
%     end
    d2logPdaunnmp12 = Negadefinize(d2logPdaunnmp12);           
    
    if d2logPdaunnmp12 ~= 0
        vaunn = d2logPdaunnmp12\dlogPdaunnmp1;
    else
        vaunn = 0;
    end

    if vaunn > 0
        stp = min( [alphaunnmp1(m+1)./vaunn ; 1] )*0.9;
    else
        stp = 0.9;
    end;

    aunnmp1_pm = aunnmp1_pm - stp*vaunn;
    alphaunnmp1=[alphaunn, aunnmp1_pm];
    alphamp1 = alphaunnmp1./sum(alphaunnmp1);

    %when m+1 == A_, can get 0 as the cond posterior mode for aunnmp1, so:
    if aunnmp1_pm < NewtonTol
        vaunn = 0;
    end

%         abs(vmu)
%         abs(vb)
%         abs(vnux)
%         abs(vnuy)
%         abs(vaunn)

    if isnan(sum(abs(vmu))+sum(abs(vb))+ sum(abs(vnux))+abs(vnuy)+abs(vaunn) )
        stoppp = 1; 
    end;

    currDiscr = sum(abs(vmu))+sum(abs(vb))+ sum(abs(vnux))+abs(vnuy)+abs(vaunn);
    if currDiscr < NewtonTol
        break
    end
    
    if newtiter == Nnewtiter && currDiscr > 10^(-2)
        currDiscr
        [mump1_pm, d2logPdmump12, bmp1_pm, d2logPdbmp12, nuxmp1_pm, d2logPdnuxmp12, nuymp1_pm, d2logPdnuymp12, aunnmp1_pm, d2logPdaunnmp12] ...
         = RetrPriorParamsSim(n, m, dx, y, x, x1, hy, hx, b, mu, nux, nuy, alphaunn, bmp1_pm0, mump1_pm0, nuxmp1_pm0, nuymp1_pm0, aunnmp1_pm0, b_, Hb_, mu_, Hmu_, A_, Anuy_, Bnuy_, Anux_, Bnux_);
        break;
    end;

end

%     if min(eig(-d2logPdmump12))<0 || min(eig(-d2logPdbmp12))<0 || min(eig(-d2logPdnuxmp12))<0 || min(eig(-d2logPdnuymp12))<0 || min(eig(-d2logPdaunnmp12))<0
%         stopp =1;
%     end

%     if newtiter == Nnewtiter
%         stopp = 1;
%     end
