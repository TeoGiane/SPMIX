%mixreg model: Compute Q with Q_{ij}=-0.5(x_i-mu_j)'Sigma_j (x_i-mu_j)
% for each i normalized along j so that max_j Q_{ij} = 1
function l = ComputeLogLklhd(n, m, dx, y, x, b, mu, nux, hx, x1, nuy, hy, alpha)

% Q = ComputeQ(n, m, dx, x, mu, nux, hx);
% aexpQ = bsxfun(@times, exp(Q), alpha);
% aexpQnorm = bsxfun(@rdivide, aexpQ, sum(aexpQ,2));
% Qy = reshape(sum(reshape(bsxfun(@times, repmat(x1',1,m), reshape(b,1,m*(dx+1)))', dx+1, m*n)),m,n)';
% Qy = bsxfun(@minus, Qy, y');
% Qy = bsxfun(@times, exp(-0.5*bsxfun(@times, Qy.^2, nuy.*hy)), sqrt(nuy.*hy));
% l =sum(log(sum(aexpQnorm.*Qy,2)));

l = sum(log(pdfycondxparam(y, x, x1, b, mu, alpha, hy, hx, nuy, nux, m)));    