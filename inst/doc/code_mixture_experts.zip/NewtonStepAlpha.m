function step = NewtonStepAlpha(alpha_pm, v) 

step = min(0.9*min(alpha_pm(v>0)./v(v>0)),1);
if isempty(step), step=0.5; end;
sumv = sum(v);
if sumv<0
   step = min(step, 0.9*(1-sum(alpha_pm))./(-sumv)); 
end
