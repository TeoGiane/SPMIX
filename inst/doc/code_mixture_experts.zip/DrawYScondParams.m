function [y, s, mult_draw, N] = DrawYScondParams(x,x1,b, mu, alpha, hy, hx, nuy, nux)

n = length(x(1,:));
dx = length(x(:,1));
m = length(b(1,:));
if m == 1
    s = ones(n,1);
    mult_draw = ones(1,n);
else
    expQ = exp(ComputeQ(n, m, dx, x, mu, nux, hx));
    [s, mult_draw] = SCondParamDraw(expQ, alpha); 
 end

N = sum(mult_draw,2);
muy = sum(b(:,s).*x1); 
sdy = 1./sqrt(hy*nuy(1,s)); 
y = normrnd(muy,sdy); % Draw y|s, param