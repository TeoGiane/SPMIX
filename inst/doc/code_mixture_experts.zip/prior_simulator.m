% Posterior simulator for the following model of y_i|x_i, i =1,n:
% p(y_i|x_i) = \sum_{j=1}^m  alpha(j)\exp[ -0.5 (x_i-mu(j))' Hx_j (x_i-mu(j))] *
% \phi(y_i,x1_i'b_j,(hy*nuy(j))^-1) /...
% \sum_{j=1}^m   alpha(j) \exp[ -0.5 (x_i-mu(j))' Hx_j (x-mu(j))]
% where x1 = [1;x];
% Hx_j = diag(hx(1)*nux(1,j),...,hx(dx}*nux(dx,j))

function [sim_b, sim_mu, sim_alphaunn, sim_hy, sim_hx, sim_nuy, sim_nux, sim_m] ...
         = prior_simulator(b_, Hb_, mu_, Hmu_, A_, Ahy_, Bhy_, Ahx_, Bhx_, Anuy_, Bnuy_, Anux_, Bnux_, Am_, Amlogp_, ...
                         Nsim)
dx = length(mu_);
invHb_ = inv(Hb_);
invHmu_ = inv(Hmu_);
mMaxInit = 20; % upper bound on m used for memory allocation before for loop

sim_b = zeros(dx+1,mMaxInit,Nsim);
sim_mu = zeros(dx,mMaxInit,Nsim);
sim_alphaunn = zeros(mMaxInit,Nsim);
sim_hy = zeros(1,Nsim); 
sim_hx = zeros(dx,Nsim); 
sim_nuy = zeros(mMaxInit,Nsim); 
sim_nux = zeros(dx,mMaxInit,Nsim);
sim_m = zeros(1,Nsim);     

if Amlogp_ == 0
    mpriorPMF = exp(-Am_.*(1:50))*(exp(Am_)-1);%knowm pmf constant
else
    mpriorPMF = exp(-Am_.*(1:50).*(log(1:50).^Amlogp_));
    mpriorPMF = mpriorPMF./sum(mpriorPMF);
end

mpriorCDF = cumsum(mpriorPMF);
 
for sim = 1:Nsim
    m = find  (rand <= mpriorCDF,1);
    sim_m(:,sim) = m;
    [sim_b(:,1:m,sim), sim_mu(:,1:m,sim), sim_alphaunn(1:m,sim), sim_hy(:,sim), sim_hx(:,sim), sim_nuy(1:m,sim), sim_nux(:,1:m,sim)] = PriorDraw(m, b_, invHb_, mu_, invHmu_, A_, Ahy_, Bhy_, Ahx_, Bhx_, Anuy_, Bnuy_, Anux_, Bnux_);
end

