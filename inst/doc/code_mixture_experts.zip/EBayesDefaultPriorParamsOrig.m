function [xm, xvar, olsb, olserrvar, b_, Hb_, mu_, Hmu_, A_, Ahy_, Bhy_, Ahx_, Bhx_, Anuy_, Bnuy_, Anux_, Bnux_, Am_, Amlogp_] = EBayesDefaultPriorParams(y,x,x1)

dx = length(x(:,1));
%Data dependent prior/empirical bayes
olsb=(x1*x1')\(x1*y');
%olsb=zeros(dx+1,1); olsb(1,1) = mean(y);
olserrvar = mean((y - olsb'*x1).^2);
xm = mean(x,2);
xvar = cov(x');
xsd = sqrt(diag(xvar));
% Note change EB prior for no beta model
b_ = olsb;%[mean(y); zeros(dx,1)];%
Hb_ = 0.001*(x1*x1')./olserrvar;%diag( [1./(std(y).^2), ones(1,dx) ]);%0.01*% 
Hb_b_ = Hb_*b_;
invHb_ = inv(Hb_);
mu_ = xm;
Hmu_ = inv(xvar);
Hmu_mu_= Hmu_*mu_;
invHmu_ = inv(Hmu_);
A_ = 8;
Am_ = 1;
Amlogp_ = 0;



% tempHym = 1; tempHyv = 1; % mode and variance for scale params prior
% tempNuym = 1; tempNuyv = 1;
% %tempHxm = 3./xsd; tempHxv = 0.1;
% tempHxm = 1; tempHxv = 1;
% tempNuxm = 1; tempNuxv = 1*ones(dx,1);%replaced 1 with 100
% GamAFromModeVar = @(md,v) ((md./sqrt(v) + sqrt((md./sqrt(v)).^2 + 4))*0.5).^2; 
% Ahy_ = GamAFromModeVar(tempHym, tempHyv); Bhy_ = (Ahy_-1)./tempHym;
% Anuy_ = GamAFromModeVar(tempNuym, tempNuyv); Bnuy_ = (Anuy_-1)./tempNuym;
% Ahx_ = GamAFromModeVar(tempHxm, tempHxv); Bhx_ = (Ahx_-1)./tempHxm;
% Anux_ = GamAFromModeVar(tempNuxm, tempNuxv); Bnux_ = (Anux_-1)./tempNuxm;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%tempHym = (500./olserrvar)^(1/2); tempHyv = 100^1; %replaced 1 with 100
tempHym = 1./(olserrvar^(1/2)); tempHyv = 10^1;
tempNuym = 1; tempNuyv = 0.1;
tempHxm = 1./xsd; tempHxv = 10^1;
tempNuxm = 1; tempNuxv = 0.1*ones(dx,1);%replaced 1 with 100
Ahy_ = (tempHym).^2./tempHyv;%2
Bhy_ = tempHym./tempHyv;%0.01;
Anuy_ = (tempNuym).^2./tempNuyv;%2
Bnuy_ = tempNuym./tempNuyv;%0.01*Anuy_*olserrvar*Ahy_/Bhy_;
Ahx_ = (tempHxm).^2./tempHxv;%2*ones(dx, 1);
Bhx_ = tempHxm./tempHxv;%0.01*ones(dx, 1);
Anux_ = (tempNuxm).^2./tempNuxv;%2*ones(dx,1);
Bnux_ = tempNuxm./tempNuxv;%0.01*ones(dx,1).*Anux_.*olserrvar.*Ahx_./Bhx_;


