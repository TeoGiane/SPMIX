% Conditional density values

function condmean = meanycondxparam(x, x1, b, mu, alphaunn, hy, hx, nuy, nux, m)
            
n = length(x(1,:));
dx = length(x(:,1));
Q = ComputeQ(n, m, dx, x, mu, nux, hx);
[aexpQnorm, ~] = Qnormsumlogsum(Q,alphaunn);
%aexpQ = bsxfun(@times, exp(Q), alphaunn);
%aexpQnorm = bsxfun(@rdivide, aexpQ, sum(aexpQ,2));
mean_by_comp = reshape(sum(reshape(bsxfun(@times, repmat(x1',1,m), reshape(b,1,m*(dx+1)))', dx+1, m*n)),m,n)';
condmean = sum(aexpQnorm.*mean_by_comp,2);
