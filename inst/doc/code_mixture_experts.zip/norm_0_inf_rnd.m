function y = norm_0_inf_rnd(mu, sigma)
% generate data for panel probit with serially correlated errors
n = length(mu);
P = normcdf(zeros(n,1), mu, sigma);
y = norminv((1-P).*rand(n,1)+P,mu,sigma);