% Posterior simulator for the following model of y_i|x_i, i =1,n:
% p(y_i|x_i) = \sum_{j=1}^m  alpha(j)\exp[ -0.5 (x_i-mu(j))' Hx_j (x_i-mu(j))] *
% \phi(y_i,x1_i'b_j,(hy*nuy(j))^-1) /...
% \sum_{j=1}^m   alpha(j) \exp[ -0.5 (x_i-mu(j))' Hx_j (x-mu(j))]
% where x1 = [1;x];
% Hx_j = diag(hx(1)*nux(1,j),...,hx(dx}*nux(dx,j))

function [sim_b, sim_mu, sim_alphaunn, sim_hy, sim_hx, sim_nuy, sim_nux, sim_m, currlogLikelihood, propPlogLikelihood] ...
         = post_simulator4(y, x, x1,...
                            b, mu, alphaunn, hy, hx, nuy, nux, m,...
                            b_, Hb_, mu_, Hmu_, A_, Ahy_, Bhy_, Ahx_, Bhx_, Anuy_, Bnuy_, Anux_, Bnux_, Am_, Amlogp_,...
                            Nsim, jdt_flag, progress_step)


% some inputs check                                                      
szy = size(y); szx = size(x); szx1 = size(x1);
dx = szx(1);
n = szy(2);
if szx(2) ~= n || szx1(2) ~= n || szy(1) ~= 1 || szx1(1) ~= dx+1  
    error('post_simulator: input dimensions do not match');
end


%precompute some statistics used by the mcmc algorithm
x1x1t = zeros(dx+1,dx+1,n);
x1ty = zeros(dx+1,n);
for i=1:n
    x1x1t(:,:,i)=x1(:,i)*x1(:,i)';
    x1ty(:,i)=x1(:,i)*y(i);
end

Hb_b_ = Hb_*b_;

mMaxInit = 20; % upper bound on m used for memory allocation before for loop, if m exceed this then more memory is allocated

bAccCount = 0;
alphaAccCount = 0;
muAccCount = zeros(1,mMaxInit);
nuxAccCount = zeros(1,mMaxInit);
hxAccCount = 0;
mp1AccCount = 0;
mm1AccCount = 0;
hyAccCount = 0;



sim_b = zeros(dx+1,mMaxInit,Nsim);
sim_mu = zeros(dx,mMaxInit,Nsim);
sim_alphaunn = zeros(mMaxInit,Nsim);
sim_hy = zeros(1,Nsim); 
sim_hx = zeros(dx,Nsim); 
sim_nuy = zeros(mMaxInit,Nsim); 
sim_nux = zeros(dx,mMaxInit,Nsim);
sim_m = zeros(1,Nsim);
%sum_alphaunn = zeros(1,Nsim);
currlogLikelihood = zeros(1,Nsim); 
propPlogLikelihood = zeros(1,Nsim);
propMlogLikelihood = zeros(1,Nsim);

nonconvcount = 0;



%
olsb=(x1*x1')\(x1*y');
olserrvar = mean((y - olsb'*x1).^2);
xmean=mean(x,2);
xvar = var(x,0,2);



alpha = alphaunn./sum(alphaunn);
Q = ComputeQ(n, m, dx, x, mu, nux, hx);
[aexpQnorm, sumlogsumkaexpQ] = Qnormsumlogsum(Q,alpha);


tic

for sim = 1:Nsim

    [b, mu, alphaunn, hy, hx, nuy, nux, N, Q, aexpQnorm, sumlogsumkaexpQ, bAccCount, muAccCount, alphaAccCount, hyAccCount,  hxAccCount, nuxAccCount] ...
         = mcmc_iter_given_m(y, x, x1, x1x1t, x1ty, dx, n,...
                                b, mu, alphaunn, hy, hx, nuy, nux, m, Q, aexpQnorm, sumlogsumkaexpQ,...
                                bAccCount, muAccCount, alphaAccCount, hyAccCount,  hxAccCount, nuxAccCount, ...
                                b_, Hb_, mu_, Hmu_, A_, Ahy_, Bhy_, Ahx_, Bhx_, Anuy_, Bnuy_, Anux_, Bnux_, Am_, Amlogp_,Hb_b_);
    
                            
	[mswdraw, b, mu, alphaunn, hy, hx, nuy, nux, sim_m(:,sim), currlogLikelihood(sim), propMlogLikelihood(sim), propPlogLikelihood(sim), mp1AccCount, mm1AccCount] ...
         = mcmc_iter_m(y, x, x1, xmean, xvar, olsb, olserrvar, dx, n,...
                        mp1AccCount, mm1AccCount, ...
                        b, mu, alphaunn, hy, hx, nuy, nux, m,...
                        b_, Hb_, mu_, Hmu_, A_, Ahy_, Bhy_, Ahx_, Bhx_, Anuy_, Bnuy_, Anux_, Bnux_, Am_, Amlogp_,Hb_b_);
                         
    % Update some intermediate vars if m changes or label switched                        
    if sim_m(:,sim) ~= m
        m = sim_m(:,sim);
        Q = ComputeQ(n, m, dx, x, mu, nux, hx);
        alpha = alphaunn./sum(alphaunn);     
        [aexpQnorm, sumlogsumkaexpQ] = Qnormsumlogsum(Q,alpha);
    else
        if mswdraw && mswdraw ~= m % a random label switch
           Qtemp = Q(:,m); Q(:,m) = Q(:,mswdraw); Q(:,mswdraw) = Qtemp;
           Qtemp = aexpQnorm(:,m); aexpQnorm(:,m) = aexpQnorm(:,mswdraw); aexpQnorm(:,mswdraw) = Qtemp;     
        end
    end
 


    
    
    if m > mMaxInit % then need to allocate more memory for storage
        mMaxD = 5;
        sim_b = cat(2, sim_b, zeros(dx+1,mMaxD,Nsim));
        sim_mu = cat(2, sim_mu, zeros(dx,mMaxD,Nsim));
        sim_alphaunn = cat(1, sim_alphaunn, zeros(mMaxD,Nsim));
        sim_nuy = cat(1, sim_nuy, zeros(mMaxD,Nsim));
        sim_nux = cat(2, sim_nux, zeros(dx,mMaxD,Nsim));
    end

% store simulated params
    sim_b(:,1:m,sim) = b;
    sim_mu(:,1:m,sim) = mu;
    sim_alphaunn(1:m,sim) = alphaunn;
    sim_hy(:,sim) = hy; 
    sim_hx(:,sim) = hx; 
    sim_nuy(1:m,sim) = nuy; 
    sim_nux(:,1:m,sim) = nux;
%    sim_m(:,sim) = m;
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if jdt_flag % simulate data for joint d-n tests
%       %draw s cond param
        alpha = alphaunn./sum(alphaunn);
        if m == 1
            s = ones(n,1);
            mult_draw = ones(1,n);
        else
%           Q = ComputeQ(n, m, dx, x, mu, nux, hx);
%           expQ = exp(bsxfun(@minus, Q, max(Q,[],2)));
%           [s, mult_draw] = SCondParamDraw(expQ, alpha); 
            mult_draw = mnrnd(1,aexpQnorm)'; [s, ~] = find(mult_draw);

        end
        N = sum(mult_draw,2);
        muy = sum(b(:,s).*x1); sdy = 1./sqrt(hy*nuy(1,s)); y = normrnd(muy,sdy);
%        [y, s, mult_draw, N] = DrawYScondParams(x,x1,b, mu, alpha, hy, hx, nuy, nux);
        %recalculate precomputed stats
        x1ty=bsxfun(@times, x1, y);
        olsb=(x1*x1')\(x1*y');
        olserrvar = mean((y - olsb'*x1).^2);
        
    end
    
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    
    if floor(sim/progress_step) == sim/progress_step, % output current mcmc stats, e.g., acceptance rates
        msg = sprintf('Iter = %d Time = %d nonconvcount = %d m = %d Params = %d %d %d %d %d %d %d %d %d', sim, toc, nonconvcount, m, b(1), mu(1), alpha(1), hy(1), nuy(1), hx(1), nux(1));
        display(msg);
        hy*nuy
        msg2 = sprintf('Acc Counts: mp1 = %d mm1 = %d AlphaAcc = %d hx = %d hy = %d MaxMu = %d MaxNux = %d N = ...', mp1AccCount, mm1AccCount, alphaAccCount, hxAccCount, hyAccCount, max(muAccCount), max(nuxAccCount));
        display(msg2);
   
%        muAccCount
%        nuxAccCount
%        hxAccCount
        N'
%      alphaunn
%       hyAccCount
        plot_postsim; drawnow;
    end
end

