%mixreg model: Compute Q with Q_{ij}=-0.5(x_i-mu_j)'Sigma_j (x_i-mu_j)
% for each i normalized along j so that max_j Q_{ij} = 1
function [mump1_pm, d2logPdmump12, bmp1_pm, d2logPdbmp12, nuxmp1_pm, d2logPdnuxmp12, nuymp1_pm, d2logPdnuymp12, aunnmp1_pm, d2logPdaunnmp12] ...
              = RetrPriorParamsSim(n, m, dx, y, x, x1, hy, hx, b, mu, nux, nuy, alphaunn, bmp1_pm0, mump1_pm0, nuxmp1_pm0, nuymp1_pm0, aunnmp1_pm0, b_, Hb_, mu_, Hmu_, A_, Anuy_, Bnuy_, Anux_, Bnux_)

% The following 2 lines and the last line in the file will make the simulations in this function deterministic, not random        
curr_rng_st = rng; % save the random number generator state
rng(0,'twister'); 
          
display('RetrPriorParamsSim was called');
          
Nsim = 20;%1000;      
rwVarAdj = 0.5;

simbmp1_pm = zeros(dx+1,Nsim); 
simmump1_pm = zeros(dx,Nsim); 
simnuxmp1_pm = zeros(dx,Nsim);
simnuymp1_pm = zeros(1,Nsim);
simaunnmp1_pm = zeros(1,Nsim);

bmp1_pm = bmp1_pm0;
mump1_pm = mump1_pm0;
nuxmp1_pm = nuxmp1_pm0;
nuymp1_pm = nuymp1_pm0;
aunnmp1_pm = aunnmp1_pm0;

bmp1 = [b, bmp1_pm];%[b, mvnrnd(b_',invHb_, 1)'];
mump1 = [mu, mump1_pm];%[mu, mvnrnd(mu_',invHmu_, 1)'];    
nuymp1 = [nuy, nuymp1_pm];%[nuy, gamrnd(Anuy_(:,1), 1./Bnuy_(:,1))];
nuxmp1 = [nux, nuxmp1_pm];%[nux, gamrnd(Anux_(:,1), 1./Bnux_(:,1))];   
alphaunnmp1 = [alphaunn,aunnmp1_pm]; % alphaunn(1:m) here is a 
alphamp1 = alphaunnmp1./sum(alphaunnmp1); 
       
          


    
%    currLogLklhd = ComputeLogLklhd(n, m, dx, y, x, b, mu, nux, hx, x1, nuy, hy, alpha);
    

    % the following commented code is for plotting likelihood at debugging
    % stage to make sure there is a unique max and Newton method works, etc
%     ComputeLogLklhdMump1 = @(z) ComputeLogLklhd(n, m+1, dx, y, x, bmp1, [mu,z], nuxmp1, hx, x1, nuymp1, hy, alphamp1);
%     ComputeLogLklhdbmp1 = @(z) ComputeLogLklhd(n, m+1, dx, y, x, [b,z], mump1, nuxmp1, hx, x1, nuymp1, hy, alphamp1);
%     ComputeLogLklhdnuxmp1 = @(z) ComputeLogLklhd(n, m+1, dx, y, x, bmp1, mump1, [nux,z], hx, x1, nuymp1, hy, alphamp1);
%     ComputeLogLklhdnuymp1 = @(z) ComputeLogLklhd(n, m+1, dx, y, x, bmp1, mump1, nuxmp1, hx, x1, [nuy,z], hy, alphamp1);

%     grdRng = 10;
%     grdSz = 100;
%     lklhdsurf = zeros(grdSz,grdSz);
%     for ii1=1:grdSz
%         for jj2 = 1:grdSz
%             z = - 0.5*grdRng +  [ii1*grdRng./grdSz;jj2*grdRng./grdSz];
%             lklhdsurf(ii1,jj2) = ComputeLogLklhdmp1(z) - 0.5*(z-mu_)'*Hmu_*(z-mu_);
%         end
%     end
%      figure(38)
%     surf(lklhdsurf)

% grdRng = 2;
% grdSz = 10000;
% lklhdy = zeros(grdSz);
% z  = zeros(grdSz);
% for ii1=1:grdSz
% 
%         z(ii1) = - 0.5*grdRng +  ii1*grdRng./grdSz;
%         lklhdy(ii1) =  - 0.5*(z(ii1)-mu_)'*Hmu_*(z(ii1)-mu_) + ComputeLogLklhdMump1(z(ii1));
% end
% figure(56)
% plot(z,lklhdy)

%     grdRng = 10;
%     grdSz = 100;
%     lklhdsurf = zeros(grdSz,grdSz);
%     z = zeros(dx+1,1);
%     for ii1=1:grdSz
%         for jj2 = 1:grdSz
%             z(dx:dx+1,1) = - 0.5*grdRng +  [ii1*grdRng./grdSz;jj2*grdRng./grdSz];
%             lklhdsurf(ii1,jj2) = ComputeLogLklhdbmp1(z);% - 0.5*(z-b_)'*Hb_*(z-b_);
%         end
%     end
%      figure(42)
%     surf(lklhdsurf)

%     grdRng = 10;
%     grdSz = 100;
%     lklhdsurf = zeros(grdSz,grdSz);
%     for ii1=1:grdSz
%         for jj2 = 1:grdSz
%             z = [ii1*grdRng./grdSz;jj2*grdRng./grdSz];
%             lklhdsurf(ii1,jj2) = ComputeLogLklhdnuxmp1(z)+(Anux_- 1)'*log(z) - Bnux_'*z;
%             %lklhdsurf(ii1,jj2) = (Anux_- 1)'*log(z) - Bnux_'*z;
%         end
%     end
%      figure(45)
%     surf(lklhdsurf)
% plot((Anux_(1)- 1)*log([1:100]*0.01) - Bnux_(1)*[1:100]*0.01);
% 

% 
%     grdRng = 2;
%     grdSz = 100;
%     lklhdy = zeros(grdSz);
%     for ii1=1:grdSz
%  
%             z(ii1) = ii1*grdRng./grdSz;
%             lklhdy(ii1) = ComputeLogLklhdnuymp1(z(ii1))+(Anuy_- 1)'*log(z(ii1)) - Bnuy_'*z(ii1);
%             %lklhdsurf(ii1,jj2) = (Anux_- 1)'*log(z) - Bnux_'*z;
% 
%     end
%      figure(45)
%     plot(z,lklhdy)

% ComputeLogLklhdaunnmp1 = @(z) ComputeLogLklhd(n, m+1, dx, y, x, bmp1, mump1, nuxmp1, hx, x1, nuymp1, hy, [alphaunn,z])
% grdRng = 20;
% grdSz = 1000;
% lklhdy = zeros(grdSz);
% for ii1=1:grdSz
% 
%         z(ii1) = ii1*grdRng./grdSz;
%         lklhdy(ii1) = ComputeLogLklhdaunnmp1(z(ii1))+(A_./(m+1)- 1)*log(z(ii1)) - z(ii1);
% end
% figure(55)
% plot(z,lklhdy)

nuxAccCount = 0;
nuyAccCount = 0;
aunnAccCount = 0;
muAccCount = 0;
bAccCount = 0;


Eps = bsxfun(@minus, y', reshape(sum(reshape(bsxfun(@times, repmat(x1',1,m+1), reshape(bmp1,1,(m+1)*(dx+1)))', dx+1, (m+1)*n)),(m+1),n)'); 
meps2hdiv2 = -0.5*bsxfun(@times, Eps.^2, nuymp1.*hy);
Qynorm = bsxfun(@times, exp( bsxfun(@minus, meps2hdiv2, max(meps2hdiv2,[],2))), sqrt(nuymp1.*hy));
Q = ComputeQ(n, m+1, dx, x, mump1, nuxmp1, hx);
[aexpQnorm, ~] = Qnormsumlogsum(Q,alphamp1);       
%Qymp1DivLcomp = Qynorm(:,m+1)./sum(aexpQnorm.*Qynorm,2);
QyQloganormmp1 = ComputeQyQloganormmp1(Eps, nuymp1, hy, Q, alphamp1);
     
for sim = 1:Nsim


    %mump1
    phil1c = QyQloganormmp1-aexpQnorm(:,m+1);
    Hmp1x_mump1 = bsxfun(@times,bsxfun(@minus,x,mump1(:,m+1)), nuxmp1(:,m+1).*hx);
    Hmp1 = diag(nuxmp1(:,m+1).*hx);
    d2logPdmump12 = -sum(phil1c)*Hmp1 ...
    + sum(bsxfun(@times, xxtvec(Hmp1x_mump1'), reshape(phil1c.*(1-aexpQnorm(:,m+1) - QyQloganormmp1), 1,1,n)),3) ... 
    - Hmu_;

    if any(isnan(d2logPdmump12(:))) || any(isinf(d2logPdmump12(:)))
        stoppp = 1;
    end

    HessMuj = Negadefinize(d2logPdmump12);
    RWPrec = -HessMuj./rwVarAdj;
    RWVar = inv(RWPrec);
    muj_p = mvnrnd(mump1_pm,RWVar)'; 
            
    Q_p = ComputeQ(n, m+1, dx, x, [mu,muj_p], nuxmp1, hx);
    [aexpQnorm_p, ~] = Qnormsumlogsum(Q_p,alphamp1);
    
    QyQloganormmp1_p = ComputeQyQloganormmp1(Eps, nuymp1, hy, Q_p, alphamp1);
    
    %Qymp1DivLcomp_p = Qynorm(:,m+1)./sum(aexpQnorm_p.*Qynorm,2);
    phil1c = QyQloganormmp1_p-aexpQnorm_p(:,m+1);
    Hmp1x_mump1 = bsxfun(@times,bsxfun(@minus,x,muj_p), nuxmp1(:,m+1).*hx);
    HessMuj = -sum(phil1c)*Hmp1 ...
    + sum(bsxfun(@times, xxtvec(Hmp1x_mump1'), reshape(phil1c.*(1-aexpQnorm_p(:,m+1) - QyQloganormmp1_p), 1,1,n)),3) ... 
    - Hmu_;

    if any(isnan(HessMuj(:))) || any(isinf(HessMuj(:)))
        stoppp = 1;
    end


    HessMuj = Negadefinize(HessMuj);
    RWPropPrec = -HessMuj./rwVarAdj;
    
    AccProb = exp( ComputeLogLklhd(n, m+1, dx, y, x, bmp1, [mu,muj_p], nuxmp1, hx, x1, nuymp1, hy, alphamp1) ...
                  -ComputeLogLklhd(n, m+1, dx, y, x, bmp1, mump1, nuxmp1, hx, x1, nuymp1, hy, alphamp1) ...
                          -0.5*(muj_p-mu_)'*Hmu_*(muj_p-mu_) + 0.5*(mump1_pm-mu_)'*Hmu_*(mump1_pm-mu_) ...
                          -lnnormpdf(muj_p,mump1_pm,RWPrec) + lnnormpdf(mump1_pm,muj_p,RWPropPrec));
    if rand < AccProb
         muAccCount = muAccCount + 1;
         mump1_pm = muj_p;
         mump1 = [mu,mump1_pm];
         aexpQnorm = aexpQnorm_p;
         QyQloganormmp1 = QyQloganormmp1_p;
         Q = Q_p;
    end

%nuxmp1
    kappa = -0.5* bsxfun(@times,bsxfun(@minus,x,mump1(:,m+1)).^2, hx);
    d2logPdnuxmp12 = sum(bsxfun(@times, xxtvec(kappa'), reshape(...
        (QyQloganormmp1-aexpQnorm(:,m+1)).*(1-aexpQnorm(:,m+1)-QyQloganormmp1), 1,1,n)),3) ... 
    - diag((Anux_- 1)./(nuxmp1_pm.^2));
 

    if any(isnan(d2logPdnuxmp12(:))) || any(isinf(d2logPdnuxmp12(:)))
        stoppp = 1;
    end


    HessNuxj = Negadefinize(d2logPdnuxmp12);
	RWPrec = -HessNuxj./rwVarAdj;%RWPrec = diag((Bnux_.^2)./Anux_);%experiemnt
    RWVar = inv(RWPrec);
    nuxj_p = mvnrnd(nuxmp1_pm,RWVar)'; 
    if all(nuxj_p > 0)
    	Q_p = ComputeQ(n, m+1, dx, x, mump1, [nux, nuxj_p], hx);
        [aexpQnorm_p, ~] = Qnormsumlogsum(Q_p,alphamp1); 
        
        %Qymp1DivLcomp_p = Qynorm(:,m+1)./sum(aexpQnorm_p.*Qynorm,2);
        QyQloganormmp1_p = ComputeQyQloganormmp1(Eps, nuymp1, hy, Q_p, alphamp1);
        
        HessNuxj = sum(bsxfun(@times, xxtvec(kappa'), reshape(...
                    (QyQloganormmp1_p-aexpQnorm_p(:,m+1)).*(1-aexpQnorm_p(:,m+1)-QyQloganormmp1_p), 1,1,n)),3) ... 
                     - diag((Anux_- 1)./(nuxj_p.^2));
                 
        if any(isnan(HessNuxj(:))) || any(isinf(HessNuxj(:)))
            stoppp = 1;
        end
                 
        HessNuxj = Negadefinize(HessNuxj);
        RWPropPrec = -HessNuxj./rwVarAdj;
        
        AccProb = exp( ComputeLogLklhd(n, m+1, dx, y, x, bmp1, mump1, [nux,nuxj_p], hx, x1, nuymp1, hy, alphamp1) ...
                       -ComputeLogLklhd(n, m+1, dx, y, x, bmp1, mump1, [nux,nuxmp1_pm], hx, x1, nuymp1, hy, alphamp1) ...
                          +Bnux_'*(nuxmp1_pm - nuxj_p)+ (Anux_- 1)'* (log(nuxj_p)-log(nuxmp1_pm)) ...        
                          -lnnormpdf(nuxj_p,nuxmp1_pm,RWPrec) + lnnormpdf(nuxmp1_pm,nuxj_p,RWPropPrec));
        if rand < AccProb 
            nuxmp1_pm = nuxj_p;
            nuxmp1 = [nux, nuxmp1_pm];
            nuxAccCount = nuxAccCount + 1;
            aexpQnorm = aexpQnorm_p;
            %Qymp1DivLcomp = Qymp1DivLcomp_p;
            QyQloganormmp1 = QyQloganormmp1_p;
            Q = Q_p;
        end
    end    
    

%b
    d2logPdbmp12 = -(hy*nuymp1(m+1)).*sum(bsxfun(@times, xxtvec(x1'), reshape(...
        QyQloganormmp1.*(1-(hy*nuymp1(m+1)).*(Eps(:,m+1).^2).*(1-QyQloganormmp1)), 1,1,n)),3) ... 
    - Hb_;

    if any(isnan(d2logPdbmp12(:))) || any(isinf(d2logPdbmp12(:)))
        stoppp = 1;
    end


    HessB = Negadefinize(d2logPdbmp12);
    RWPrec = -HessB./rwVarAdj;
    RWVar = inv(RWPrec);
    b_p = mvnrnd(bmp1_pm,RWVar)';
    Eps_p = bsxfun(@minus, y', reshape(sum(reshape(bsxfun(@times, repmat(x1',1,m+1), reshape([b,b_p],1,(m+1)*(dx+1)))', dx+1, (m+1)*n)),(m+1),n)'); 
    meps2hdiv2_p = -0.5*bsxfun(@times, Eps_p.^2, nuymp1.*hy);
    Qynorm_p = bsxfun(@times, exp( bsxfun(@minus, meps2hdiv2_p, max(meps2hdiv2_p,[],2))), sqrt(nuymp1.*hy));
    %Qymp1DivLcomp_p = Qynorm_p(:,m+1)./sum(aexpQnorm.*Qynorm_p,2);
    QyQloganormmp1_p = ComputeQyQloganormmp1(Eps_p, nuymp1, hy, Q, alphamp1);

    HessB =  -(hy*nuymp1(m+1)).*sum(bsxfun(@times, xxtvec(x1'), reshape(...
        QyQloganormmp1_p.*(1-(hy*nuymp1(m+1)).*(Eps_p(:,m+1).^2).*(1-QyQloganormmp1_p)), 1,1,n)),3) ... 
    - Hb_;

    if any(isnan(HessB(:))) || any(isinf(HessB(:)))
        stoppp = 1;
    end


    HessB = Negadefinize(HessB);
    RWPropPrec = -HessB./rwVarAdj;
    
    AccProb = exp( ComputeLogLklhd(n, m+1, dx, y, x, [b,b_p], mump1, nuxmp1, hx, x1, nuymp1, hy, alphamp1) ...
                  -ComputeLogLklhd(n, m+1, dx, y, x, [b,bmp1_pm], mump1, nuxmp1, hx, x1, nuymp1, hy, alphamp1) ...
                          -0.5*(b_p-b_)'*Hb_*(b_p-b_) + 0.5*(bmp1_pm-b_)'*Hb_*(bmp1_pm-b_) ...
                          -lnnormpdf(b_p,bmp1_pm,RWPrec) + lnnormpdf(bmp1_pm,b_p,RWPropPrec));
    if rand < AccProb
         bmp1_pm = b_p;
         Eps = Eps_p;
         Qynorm = Qynorm_p;
         %Qymp1DivLcomp = Qymp1DivLcomp_p;
         QyQloganormmp1 = QyQloganormmp1_p;
         bmp1 = [b,bmp1_pm];
         bAccCount = bAccCount + 1;
    end
    
%nuy
    kappay = -0.5* (Eps(:,m+1).^2)*hy;
    d2logPdnuymp12 = sum(   QyQloganormmp1.*(  ((kappay+0.5./nuymp1(:,m+1)).^2).*(1-QyQloganormmp1_p) -0.5./ nuymp1(:,m+1).^2)) ... 
                     - diag((Anuy_- 1)./(nuymp1(:,m+1).^2));
                
    if any(isnan(d2logPdnuymp12(:))) || any(isinf(d2logPdnuymp12(:)))
        stoppp = 1;
    end
                
                 
    HessNuyj = Negadefinize(d2logPdnuymp12);
	RWPrec = -HessNuyj./rwVarAdj;%RWPrec = diag((Bnux_.^2)./Anux_);%experiemnt
    RWVar = inv(RWPrec);
    nuyj_p = mvnrnd(nuymp1_pm,RWVar)'; 
    if all(nuyj_p > 0)
        
        meps2hdiv2_p = -0.5*bsxfun(@times, Eps.^2, [nuy,nuyj_p] .*hy);
        Qynorm_p = bsxfun(@times, exp( bsxfun(@minus, meps2hdiv2_p, max(meps2hdiv2_p,[],2))), sqrt([nuy,nuyj_p].*hy));
        %Qymp1DivLcomp_p = Qynorm_p(:,m+1)./sum(aexpQnorm.*Qynorm_p,2);
        QyQloganormmp1_p = ComputeQyQloganormmp1(Eps, [nuy,nuyj_p], hy, Q, alphamp1);

        HessNuyj = sum(   QyQloganormmp1_p.*(  ((kappay+0.5./nuyj_p).^2).*(1-QyQloganormmp1_p) -0.5./ nuyj_p.^2)) ... 
                     - diag((Anuy_- 1)./(nuyj_p.^2));
                 
        if any(isnan(HessNuyj(:))) || any(isinf(HessNuyj(:)))
            stoppp = 1;
        end

                 
        HessNuyj = Negadefinize(HessNuyj);
        RWPropPrec = -HessNuyj./rwVarAdj;
        
        AccProb = exp( ComputeLogLklhd(n, m+1, dx, y, x, bmp1, mump1, nuxmp1, hx, x1, [nuy, nuyj_p], hy, alphamp1) ...
                       -ComputeLogLklhd(n, m+1, dx, y, x, bmp1, mump1, nuxmp1, hx, x1, [nuy,nuymp1_pm], hy, alphamp1) ...
                          +Bnuy_'*(nuymp1_pm - nuyj_p)+ (Anuy_- 1)'* (log(nuyj_p)-log(nuymp1_pm)) ...        
                          -lnnormpdf(nuyj_p,nuymp1_pm,RWPrec) + lnnormpdf(nuymp1_pm,nuyj_p,RWPropPrec));
        if rand < AccProb 
            nuymp1_pm = nuyj_p;
            nuymp1 = [nuy, nuymp1_pm];
            nuyAccCount = nuyAccCount + 1;
            Qynorm = Qynorm_p;
            %Qymp1DivLcomp = Qymp1DivLcomp_p;
            QyQloganormmp1 = QyQloganormmp1_p;
        end
     end   







%Newton stp for alphaunnmp1 (unnormalized alpha_mp1)

      %unnormalize alpha
     %Qy = bsxfun(@times, exp(-0.5*bsxfun(@times, Eps.^2, nuymp1.*hy)), sqrt(nuymp1.*hy));

    d2logPdaunnmp12 = sum(  ( aexpQnorm(:,m+1).^2 - QyQloganormmp1.^2)./(alphaunnmp1(m+1).^2)  ) -  (A_./(m+1)-1)./(alphaunnmp1(m+1).^2);
    
    if any(isnan(d2logPdaunnmp12(:))) || any(isinf(d2logPdaunnmp12(:)))
        stoppp = 1;
    end
   
    
	HessAunn = Negadefinize(d2logPdaunnmp12);
	RWPrec = -HessAunn./rwVarAdj;%RWPrec = diag((Bnux_.^2)./Anux_);%experiemnt
    RWVar = inv(RWPrec);
    aunnmp1_p = normrnd(aunnmp1_pm,sqrt(RWVar))'; 
    if aunnmp1_p > 0
        [aexpQnorm_p, ~] = Qnormsumlogsum(Q,[alphaunn, aunnmp1_p]);  
        %Qymp1DivLcomp_p = Qynorm(:,m+1)./sum(aexpQnorm_p.*Qynorm,2);
        QyQloganormmp1_p = ComputeQyQloganormmp1(Eps, nuymp1, hy, Q, [alphaunn, aunnmp1_p]);
        HessAunn = sum(  (aexpQnorm_p(:,m+1).^2 - QyQloganormmp1_p.^2)./( aunnmp1_p.^2) ) -  (A_./(m+1)-1)./(aunnmp1_p.^2);
        
        if any(isnan(HessAunn(:))) || any(isinf(HessAunn(:)))
            stoppp = 1;
        end
        
        HessAunn = Negadefinize(HessAunn);
        RWPropPrec = -HessAunn./rwVarAdj;
        
        AccProb = exp( ComputeLogLklhd(n, m+1, dx, y, x, bmp1, mump1, nuxmp1, hx, x1, [nuy, nuyj_p], hy, [alphaunn, aunnmp1_p]) ...
                       -ComputeLogLklhd(n, m+1, dx, y, x, bmp1, mump1, nuxmp1, hx, x1, [nuy,nuymp1_pm], hy, alphamp1) ...
                          +(A_./(m+1)-1)*(log(aunnmp1_p)-log(aunnmp1_pm)) - (aunnmp1_p-aunnmp1_pm) ...        
                          -lnnormpdf(aunnmp1_p,aunnmp1_pm,RWPrec) + lnnormpdf(aunnmp1_pm,aunnmp1_p,RWPropPrec));
        if rand < AccProb 
            aunnmp1_pm = aunnmp1_p;
            alphaunnmp1=[alphaunn, aunnmp1_pm];
            alphamp1 = alphaunnmp1./sum(alphaunnmp1);
            aunnAccCount = aunnAccCount  + 1;
            %Qymp1DivLcomp = Qymp1DivLcomp_p;
            QyQloganormmp1= QyQloganormmp1_p;
            aexpQnorm = aexpQnorm_p;
        end
     end   


    simbmp1_pm(:,sim) = bmp1_pm; 
    simmump1_pm(:,sim) = mump1_pm; 
    simnuxmp1_pm(:,sim) = nuxmp1_pm;
    simnuymp1_pm(:,sim) = nuymp1_pm;
    simaunnmp1_pm(:,sim) = aunnmp1_pm;

end

bmp1_pm = mean(simbmp1_pm,2); 
mump1_pm = mean(simmump1_pm,2); 
nuxmp1_pm = mean(simnuxmp1_pm,2);
nuymp1_pm = mean(simnuymp1_pm,2);
aunnmp1_pm = mean(simaunnmp1_pm,2);

d2logPdmump12 = -inv(sum(xxtvec(bsxfun(@minus,simmump1_pm,mump1_pm)'),3)./Nsim);
d2logPdbmp12 = -inv(sum(xxtvec(bsxfun(@minus,simbmp1_pm,bmp1_pm)'),3)./Nsim);
d2logPdnuxmp12 = -inv(sum(xxtvec(bsxfun(@minus,simnuxmp1_pm,nuxmp1_pm)'),3)./Nsim);
d2logPdnuymp12 = -1./(mean((simnuymp1_pm - nuymp1_pm).^2));
d2logPdaunnmp12 = -1./(mean((simaunnmp1_pm - aunnmp1_pm).^2));


% return the random number generator to the state before this function was called
rng(curr_rng_st); 

