function [helle, mae] = hellingermaenpcpdf(dgppdfeval, ygrid, xgrid, flagRecalc)

xgridlen = length(xgrid(1,:));
ypdf = reshape(repmat(ygrid, length(xgrid(1,:)), 1),1, length(ygrid)*length(xgrid(1,:)));
xpdf = repmat(xgrid, 1, length(ygrid));

if flagRecalc
    dataforRpred=[xpdf' ypdf'];
    save 'PreDataForR.txt' dataforRpred -ascii;
%    path(path,'C:/Program Files/R/R-3.2.2/bin');
    
    system('R CMD BATCH npest.r'); 
end

npcpdfvals = importdata('cdensPreFromR.txt');
           
condpdftrue = dgppdfeval(ypdf, xpdf);
abserror = abs(condpdftrue - npcpdfvals');
mae = sum(abserror)./length(abserror);
errorsqrt2 = (sqrt(condpdftrue) - sqrt(npcpdfvals')).^2;
helle = sum(errorsqrt2)./length(errorsqrt2); %hellinger divided by grid length on y



