% script to be run after post_simulator, it plots post simultor output and
% performs mean equality tests for first and second moments of post

fig_start_n = 20;
batch_len = 100; % batch length for computing n.s.e.
burnin_len = 1;
ts_filter=burnin_len:Nsim;

true_param_flag = 0;

mMin = min(sim_m);
m0 = mMin;

figure(fig_start_n+1)
for testd = 1:dx+1;
    for param_index = 1:mMin
        subplot(1,2,1);
        plot(squeeze(sim_b(testd,param_index,ts_filter)));
        hold on;

        subplot(1,2,2);
        [f, z] = ksdensity(squeeze(sim_b(testd,param_index,burnin_len:end)));
        %figure(fig_start_n+param_index )
        plot(z,f); 
        hold on;
        test_series = squeeze(sim_b(testd,param_index,:));
        t_stat_b_mean = (mean(test_series)-b_(testd))./ bmse(test_series,batch_len ) % t statistics for means equality test
        t_stat_bsq_mean = (mean(test_series.^2)-(b_(testd).^2+1/Hb_(testd,testd)))./ bmse(test_series.^2,batch_len ) % t statistics for means equality test
    end
    if ~jdt_flag & true_param_flag
        subplot(1,2,2);
        for param_index = 1:m0
            z = [b0(testd,param_index), b0(testd,param_index)];
            f = ylim;
            plot(z,f); 
            hold on;
        end
    end

end
range = xlim; z = range(1):(range(2)-range(1))./200:range(2);
f = normpdf(z, b_(1), 1/sqrt(Hb_(1))); %prior density for beta
plot(z,f,'LineStyle','--'); hold on;
title('\beta_{1j}');

test_series = squeeze(sim_b(1,:)) - squeeze(sim_b(2,:));
t_stat_conv_b1eqb2 = mean(test_series)./ bmse(test_series,batch_len ) % t statistics for means equality test




figure(fig_start_n+2)
for param_index = 1:1
    subplot(1,2,1);
    plot(squeeze(sim_hy(param_index,ts_filter)));
    hold on;
    
    subplot(1,2,2);
    [f, z] = ksdensity(squeeze(sim_hy(param_index,burnin_len:end)));
    %figure(fig_start_n+param_index )
    plot(z,f); 
    hold on;
    if ~jdt_flag & true_param_flag
        z = [hy0, hy0];
        f = ylim;
        plot(z,f); 
        hold on;
    end
end
hy_prdraws = gamrnd(Ahy_, 1./Bhy_, 10000, 1).^2;
[f, z] = ksdensity(hy_prdraws);
plot(z,f,'LineStyle','--'); hold on;
title('hy_j');

test_series = squeeze(sim_hy(1,:));
t_stat_hy = (mean(test_series) - mean(hy_prdraws))./ sqrt(bmse(test_series,batch_len ).^2 + bmse(hy_prdraws,batch_len ).^2) % t statistics for means equality test
t_stat_hysq = (mean(test_series.^2) - mean(hy_prdraws.^2))./ sqrt(bmse(test_series.^2,batch_len ).^2 + bmse(hy_prdraws.^2,batch_len ).^2) % t statistics for means equality test



figure(fig_start_n+3)
for param_index = 1:mMin
    
    subplot(1,2,1);
    plot(squeeze(sim_nuy(param_index,ts_filter)));
    hold on;
    
    subplot(1,2,2);
    [f, z] = ksdensity(squeeze(sim_nuy(param_index,burnin_len:end)));
    %figure(fig_start_n+param_index )
    plot(z,f); 
    hold on;
    nuy_prdraws = gamrnd(Anuy_, 1./Bnuy_, 10000, 1);
    test_series = squeeze(sim_nuy(param_index,:));
    t_stat_nuy1 = (mean(test_series) - mean(nuy_prdraws))./ sqrt(bmse(test_series,batch_len ).^2 + bmse(nuy_prdraws,batch_len ).^2) % t statistics for means equality test
    t_stat_nuy1sq = (mean(test_series.^2) - mean(nuy_prdraws.^2))./ sqrt(bmse(test_series.^2,batch_len ).^2 + bmse(nuy_prdraws.^2,batch_len ).^2) % t statistics for means equality test

end
if ~jdt_flag & true_param_flag
    subplot(1,2,2);
    for param_index = 1:m0
        z = [nuy0(param_index), nuy0(param_index)];
        f = ylim;
        plot(z,f); 
        hold on;
    end
end
nuy_prdraws = gamrnd(Anuy_(1), 1./Bnuy_(1), 10000, 1);
[f, z] = ksdensity(nuy_prdraws);
plot(z,f,'LineStyle','--'); hold on;
title('\nu_{yj}');
% test_series = squeeze(sim_nuy(1,:)) - squeeze(sim_nuy(2,:));
% t_stat_conv_nuy1_nuy2 = mean(test_series)./ bmse(test_series,batch_len ) % t statistics for means equality test


figure(fig_start_n+4)

%sim_alpha1 = sim_alphaunn(1,burnin_len:end)./sum(sim_alphaunn(:,burnin_len:end));
for param_index = 1:1
    subplot(1,2,1);
    plot(squeeze(sim_alphaunn(param_index,ts_filter)));
    hold on;
%     subplot(1,3,3);
%     [f, z] = ksdensity(sim_alpha1(sim_alpha1 < 1), 'support', [0 1.000001]);
%     plot(z,f); 
%     hold on;
end
subplot(1,2,2);
[f, z] = ksdensity(sum(sim_alphaunn(:,burnin_len:end)));
plot(z,f); 
hold on;
range = xlim; z = range(1):(range(2)-range(1))./200:range(2);
f = gampdf(z, A_, 1);
plot(z,f,'LineStyle','--'); hold on;
title('Sum 1 to m of unnorm \alpha_j');

test_series = sum(sim_alphaunn);
t_stat_unnalphasum = (mean(test_series)-A_)./ bmse(test_series,batch_len ) % t statistics for means equality test
gamma_Ex2 = A_.^2+A_;
test_series = sum(sim_alphaunn).^2;
t_stat_unnalphasumsq = (mean(test_series)-gamma_Ex2)./ bmse(test_series,batch_len ) % t statistics for means equality test
if ~jdt_flag & true_param_flag 
   for param_index = 1:m0
       f = ylim;
       z = [alpha0(param_index), alpha0(param_index)];
       plot(z,f); 
       hold on;
   end
end

% subplot(1,3,3);
% sim_alpha = bsxfun(@rdivide, sim_alphaunn, sum(sim_alphaunn));
% for param_index = 1:m0
%     [f, z] = ksdensity(squeeze(sim_alpha(param_index,burnin_len:end)));
%     %figure(fig_start_n+param_index )
%     plot(z,f); 
%     hold on;
%     test_series = squeeze(sim_alpha(param_index,:));
%     t_statAlpha = (mean(test_series)-1./m0)./ bmse(test_series,batch_len ) % t statistics for means equality test
%     beta_Ex2 = ((A_./m0).^2 + (A_./m0).*((m0-1)*A_./m0)./(A_+1))./(A_).^2;
%     test_series = squeeze(sim_alpha(param_index,:).^2);
%     t_statAlpha2 = (mean(test_series)-beta_Ex2)./ bmse(test_series,batch_len ) % t statistics for means equality test
% end
% range = xlim; z = range(1):(range(2)-range(1))./200:range(2);
% f = betapdf(z, A_./m0, (m0-1)*A_./m0);
% plot(z,f,'LineStyle','--'); hold on;
% title('\alpha_j');




figure(fig_start_n+5)
for param_index = 1:mMin
    for testd = 1:dx 

        subplot(1,2,1);
        plot(squeeze(sim_mu(1,param_index,ts_filter)));
        hold on;

        subplot(1,2,2);
        [f, z] = ksdensity(squeeze(sim_mu(testd,param_index,burnin_len:end)));
        %figure(fig_start_n+param_index )
        plot(z,f); 
        hold on;
        test_series = squeeze(sim_mu(testd,param_index,:));
        t_stat_mu = (mean(test_series) - mu_(testd))./ bmse(test_series,batch_len ) % t statistics for means equality test
        test_series = squeeze(sim_mu(1,param_index,:)).^2 - (mu_(testd).^2 + 1./Hmu_(testd,testd));
        t_stat_musq = mean(test_series)./ bmse(test_series,batch_len ) % t statistics for means equality test
    end
end

if ~jdt_flag & true_param_flag
    for param_index = 1:m0
        z = [mu0(testd,param_index), mu0(testd,param_index)];
        f = ylim;
        plot(z,f); 
        hold on;
    end
end


range = xlim; z = range(1):(range(2)-range(1))./200:range(2);
f = normpdf(z, mu_(testd), 1/sqrt(Hmu_(testd,testd))); %prior density for beta
plot(z,f,'LineStyle','--'); hold on;
title('\mu_{dj}');



figure(fig_start_n+6)
for testd = 1:dx
    for param_index = 1:mMin
        subplot(1,2,1);
        plot(squeeze(sim_nux(testd,param_index,ts_filter)));
        hold on;

        subplot(1,2,2);
        [f, z] = ksdensity(squeeze(sim_nux(testd,param_index,burnin_len:end)));
        %figure(fig_start_n+param_index )
        plot(z,f); 
        hold on;
        test_series = squeeze(sim_nux(testd,param_index,:));
        test_series = test_series - gamrnd(Anux_(testd), 1./Bnux_(testd), length(test_series), 1);
        t_stat_nux = mean(test_series)./ bmse(test_series,batch_len ) % t statistics for means equality test
        test_series = squeeze(sim_nux(testd,param_index,:)).^2;
        test_series = test_series - gamrnd(Anux_(testd), 1./Bnux_(testd), length(test_series), 1).^2;
        t_stat_nuxsq = mean(test_series)./ bmse(test_series,batch_len ) % t statistics for means equality test


    end
end
if ~jdt_flag & true_param_flag
    for param_index = 1:m0
        z = [nux0(testd,param_index), nux0(testd,param_index)];
        f = ylim;
        plot(z,f); 
        hold on;
    end
end

[f, z] = ksdensity(gamrnd(Anux_(testd), 1./Bnux_(testd), 1, length(test_series)));
plot(z,f,'LineStyle','--'); hold on;
title('\nu_{x1j}');




figure(fig_start_n+7)
hx_prdraws = gamrnd(repmat(Ahx_, 1, Nsim-burnin_len+1), repmat(1./Bhx_,1,Nsim-burnin_len+1)).^2;
for testd = 1:dx
    subplot(1,2,1);
    plot(squeeze(sim_hx(testd,ts_filter)));
    hold on;
    
    subplot(1,2,2);
    [f, z] = ksdensity(squeeze(sim_hx(testd,burnin_len:end)));
    %figure(fig_start_n+param_index )
    plot(z,f); 
    hold on;
    if ~jdt_flag & true_param_flag
        z = [hx0(testd), hx0(testd)];
        f = ylim;
        plot(z,f); 
        hold on;
    end
    test_series = sim_hx(testd,:) -hx_prdraws(testd,:) ;
    %test_series = test_series - gamrnd(Ahx_(testd), 1./Bhx_(testd), 1, length(test_series));
    t_stat_hx = mean(test_series)./ bmse(test_series,batch_len ) % t statistics for means equality test
    test_series = sim_hx(testd,:).^2 -hx_prdraws(testd,:).^2;
    %test_series = test_series - gamrnd(Ahx_(testd), 1./Bhx_(testd), 1, length(test_series)).^2;
    t_stat_hxsq = mean(test_series)./ bmse(test_series,batch_len ) % t statistics for means equality test
    [f, z] = ksdensity(hx_prdraws(testd,:));
    plot(z,f,'LineStyle','--'); hold on;
    title('h_{x1j}');

end





freqm = zeros(1,max(sim_m));

if Amlogp_ == 0
    probm = exp(-Am_*(1:max(sim_m)))*(exp(Am_)-1);%knowm pmf constant
    m_prior_mean = 1./(1-exp(-Am_));
else
    mpriorPMF = exp(-Am_.*(1:50).*(log(1:50).^Amlogp_));
    mpriorPMF = mpriorPMF./sum(mpriorPMF);
    m_prior_mean = (1:50)*mpriorPMF';
    probm = mpriorPMF(1:max(sim_m));
end

test_series = sim_m - m_prior_mean;
t_stat_m = mean(test_series)./ bmse(test_series,batch_len )



for msupp = 1:max(sim_m)
   freqm(msupp) = sum(sim_m == msupp)./length(sim_m);
end
figure(fig_start_n+8)
subplot(1,2,1);
plot(squeeze(sim_m(ts_filter)));
hold on;

subplot(1,2,2);
plot(freqm)
hold on;
plot(probm,'LineStyle','--')
title('m');

ind_j = find(probm*Nsim > 100); % test only values of m for wich effective sample size at least 100 
for j = ind_j
    test_series = sim_m == j;
    t_stat_probmej = (mean(test_series)-probm(j))./ bmse(test_series,batch_len );
    [j, t_stat_probmej]
end
